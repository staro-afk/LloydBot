# WA Bot Group — Versi Final

Bot WhatsApp berbasis Baileys, sudah lolos semua perbaikan (install error, admin-check bug, dsb) selama proses development di Termux.

## 🚀 Install dari Nol di HP (Termux)

```bash
pkg update -y && pkg upgrade -y
pkg install nodejs git python ffmpeg yt-dlp -y
mkdir -p ~/nefo
cd ~/nefo
```

Extract isi ZIP ini ke folder `~/nefo` (pakai file manager, atau `unzip` kalau ZIP-nya ada di storage yang bisa diakses Termux).

```bash
cd ~/nefo
npm install --legacy-peer-deps
```

Kalau `npm install` sudah bersih tanpa `npm error` merah:

```bash
npm start
```

Masukkan nomor WA yang mau dijadikan bot (format `628xxxxxxxxx`), nanti keluar **kode pairing 8 digit**. Buka WhatsApp di HP kamu → **Perangkat Tertaut** → **Tautkan Perangkat** → **Tautkan dengan nomor telepon** → masukkan kode itu.

Edit `config.js` dulu kalau mau ganti prefix, nomor owner, dll.

## 🔋 Biar Bot Jalan 24 Jam di HP Lama

1. **Colok charger terus** — HP harus selalu terhubung listrik.
2. **Matikan optimasi baterai buat Termux**: Settings HP → Apps → Termux → Battery → pilih "Unrestricted" / "Tidak dibatasi" (nama menu beda-beda tergantung merk HP, cari yang intinya begitu).
3. **Kunci Termux biar nggak di-kill Android**: buka app switcher (recent apps), cari Termux, tap ikon kunci/pin di pojok card-nya kalau ada opsi itu.
4. **Pasang `termux-wake-lock`** biar CPU nggak sleep saat layar mati:
   ```bash
   pkg install termux-api -y
   termux-wake-lock
   ```
   (Kalau `termux-api` gagal install karena butuh app Termux:API terpisah dari Play Store/F-Droid dan kamu nggak punya, skip langkah ini — poin 1 & 2 tetap paling penting.)
5. **Jalankan bot pakai `nohup`** biar tetap hidup meskipun kamu keluar dari sesi terminal:
   ```bash
   cd ~/nefo
   nohup npm start > bot.log 2>&1 &
   ```
   Nanti kalau mau lihat log-nya: `tail -f bot.log`
   Kalau mau matikan bot: cari process ID-nya dulu `ps aux | grep node`, lalu `kill <PID>`.

6. **Auto-restart kalau bot crash** (opsional, lebih niat): pakai `pm2`:
   ```bash
   npm install -g pm2
   cd ~/nefo
   pm2 start index.js --name wabot
   pm2 save
   ```
   Bot otomatis restart sendiri kalau error/crash. Cek status: `pm2 status`, lihat log: `pm2 logs wabot`.

**Catatan realistis:** Android tetap bisa membunuh proses background sewaktu-waktu meskipun sudah ikutin semua di atas (tergantung merk HP — Xiaomi/Oppo/Vivo terkenal agresif soal ini). Kalau bot suka mati sendiri, cek lagi pengaturan baterai khusus merk HP kamu (biasanya ada menu tambahan selain "Battery" standar Android, misal "Autostart" di MIUI).

## 📋 Daftar Fitur

**Umum:** menu, ping, owner, afk, brat, sticker, toimg, quotly, fakecall
**Downloader:** play (audio YouTube), ytmp4 (video YouTube), tiktok (no watermark)
**Grup:** hidetag, kick, add, promote, demote, groupinfo, welcome on/off, antilink on/off, antispam otomatis + resetwarn

## ⚠️ Dependency Eksternal (WAJIB terpasang lewat `pkg`, bukan `npm`)

- `ffmpeg` → dipakai bikin sticker dari gambar/video
- `yt-dlp` → dipakai fitur `play` & `ytmp4`

Kalau salah satu ini belum ke-install, fitur terkait bakal error "command not found".
