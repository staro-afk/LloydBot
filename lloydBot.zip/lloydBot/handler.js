const fs = require("fs");
const path = require("path");
const { downloadMediaMessage, jidNormalizedUser } = require("@whiskeysockets/baileys");
const axios = require("axios");
const config = require("./config");
const { removeBackground } = require("./lib/removebg");
const db = require("./lib/database");
const { generateBratImage } = require("./lib/brat");
const { bufferToSticker } = require("./lib/sticker");
const { generateFakeCallImage } = require("./lib/fakecall");
const { generateIqcImage, parseReactions } = require("./lib/iqc");
const economy = require("./lib/economy");
const ular = require("./lib/ulartangga");
const tebak = require("./lib/tebak");
const { askGemini } = require("./lib/ai");
const {
  searchYoutube,
  downloadYoutubeAudio,
  downloadYoutubeVideo,
  tiktokNoWatermark,
  generateQuotly,
  stalkTikTok,
  stalkInstagram,
  formatStalkCaption,
} = require("./lib/downloader");
const { runGameCheck } = require("./lib/gamecheck");
const { stalkRoblox, formatRobloxParts, fetchAvatarBuffer, cooldownLeft } = require("./lib/roblox");
const { buildMenu } = require("./lib/menu");

const startTime = Date.now();
const kerjaCooldown = new Map();
const KERJA_COOLDOWN_MS = 10000;
const OWNER_EFFECTIVE_LEVEL = 10000000;
const MAX_LEVEL = 1000;

function getText(msg) {
  const m = msg.message;
  if (!m) return "";
  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    ""
  );
}

function getQuoted(msg) {
  const ctx = msg.message?.extendedTextMessage?.contextInfo;
  if (!ctx || !ctx.quotedMessage) return null;
  return {
    key: {
      remoteJid: msg.key.remoteJid,
      id: ctx.stanzaId,
      participant: ctx.participant,
      fromMe: false,
    },
    message: ctx.quotedMessage,
  };
}

async function isSenderAdmin(sock, groupId, sender) {
  const metadata = await sock.groupMetadata(groupId);
  const senderJid = jidNormalizedUser(sender);
  const participant = metadata.participants.find(
    (p) => jidNormalizedUser(p.id) === senderJid || jidNormalizedUser(p.lid || "") === senderJid
  );
  return participant?.admin === "admin" || participant?.admin === "superadmin";
}

async function isBotAdmin(sock, groupId) {
  const metadata = await sock.groupMetadata(groupId);
  const botJid = jidNormalizedUser(sock.user.id);
  const botLid = sock.user.lid ? jidNormalizedUser(sock.user.lid) : null;
  const participant = metadata.participants.find((p) => {
    const pJid = jidNormalizedUser(p.id);
    const pLid = p.lid ? jidNormalizedUser(p.lid) : null;
    return pJid === botJid || (botLid && pLid === botLid) || (botLid && pJid === botLid) || (pLid && pLid === botJid);
  });
  return participant?.admin === "admin" || participant?.admin === "superadmin";
}

async function handleUlarRoll(sock, msg, from, sender) {
  const result = ular.rollDice(from, sender);
  if (result.error) {
    await sock.sendMessage(from, { text: result.error }, { quoted: msg });
    return;
  }

  let text = `🎲 ${result.playerName} lempar dadu: *${result.roll}*\n`;
  if (result.overshoot) {
    text += `Kelebihan langkah, posisi tetap di ${result.oldPos}.`;
  } else {
    text += `${result.oldPos} ➜ ${result.newPos}`;
    if (result.laddersnake) {
      const emoji = result.laddersnake.type === "tangga" ? "🪜 Naik tangga!" : "🐍 Kena ular, turun!";
      text += `\n${emoji} ${result.laddersnake.from} ➜ ${result.laddersnake.to}`;
    }
  }

  if (result.won) {
    text += `\n\n🏆 *${result.playerName} MENANG!* Game selesai.`;
  } else if (result.mode === "multi" && result.nextPlayer) {
    text += `\n\nGiliran selanjutnya: *${result.nextPlayer.name}*`;
  } else if (result.mode === "solo") {
    text += `\n\nKetik ${config.prefix}kocok lagi buat lanjut.`;
  }

  try {
    const img = await ular.generateBoardImage(result.players);
    await sock.sendMessage(from, { image: img, caption: text }, { quoted: msg });
  } catch (e) {
    await sock.sendMessage(from, { text }, { quoted: msg });
  }
}

function formatDuration(ms) {
  const s = Math.floor(ms / 1000) % 60;
  const m = Math.floor(ms / 60000) % 60;
  const h = Math.floor(ms / 3600000);
  return `${h}j ${m}m ${s}d`;
}

function rawNumber(jid) {
  return (jid || "").split("@")[0].split(":")[0].replace(/\D/g, "");
}

async function isOwner(sock, isGroup, groupId, jid) {
  const owner = (config.ownerNumber || "").replace(/\D/g, "");
  const ownerLid = config.ownerLid || "";

  if (ownerLid && jidNormalizedUser(jid) === jidNormalizedUser(ownerLid)) return true;
  if (owner && rawNumber(jid) === owner) return true;

  if (isGroup) {
    try {
      const metadata = await sock.groupMetadata(groupId);
      const jidNorm = jidNormalizedUser(jid);
      const participant = metadata.participants.find(
        (p) => jidNormalizedUser(p.id) === jidNorm || (p.lid && jidNormalizedUser(p.lid) === jidNorm)
      );
      if (participant) {
        if (owner && rawNumber(participant.id) === owner) return true;
        if (owner && participant.lid && rawNumber(participant.lid) === owner) return true;
        if (ownerLid && jidNormalizedUser(participant.id) === jidNormalizedUser(ownerLid)) return true;
        if (ownerLid && participant.lid && jidNormalizedUser(participant.lid) === jidNormalizedUser(ownerLid)) return true;
      }
    } catch (e) {}
  }
  return false;
}

const MENU_TEXT = (pfx) => `
╭───〔 *${config.botName}* 〕
│ Prefix: *${pfx}*
╰──────────────────────
╭──────────────
│*DASAR*
│• ${pfx}menu
│• ${pfx}ping
│• ${pfx}owner
│• ${pfx}afk <alasan>
│• ${pfx}public / ${pfx}self / ${pfx}sleep
╰──────────────────────
╭──────────────
│*MEDIA*
│• ${pfx}sticker / ${pfx}s (balas gambar/video)
│• ${pfx}rbg (balas gambar)
│• ${pfx}toimg (balas sticker)
│• ${pfx}brat <teks>
│• ${pfx}quotly (balas chat)
│• ${pfx}fakecall <nama|durasi|jam|status>
│• ${pfx}iqc <teks|waktu|reaksi>
│• ${pfx}tiktok / ${pfx}tt <link>
│• ${pfx}ttstalk / ${pfx}stalktiktok <username>
│• ${pfx}igstalk / ${pfx}stalkig <username>
│• ${pfx}play <judul>
│• ${pfx}ytmp4 <judul/link>
╰──────────────────────
╭──────────────
│*GRUP* (admin, kecuali disebutkan)
│• ${pfx}hidetag <pesan>
│• ${pfx}kick @user
│• ${pfx}add 62xxx
│• ${pfx}promote @user
│• ${pfx}demote @user
│• ${pfx}groupinfo
│• ${pfx}welcome on/off
│• ${pfx}antilink on/off
│• ${pfx}resetwarn @user
╰──────────────────────
╭──────────────
│*GAME*
│• ${pfx}ular start solo/multi
│• ${pfx}ular join / begin / status / batal
│• ${pfx}kocok
│• ${pfx}tebakangka
│• ${pfx}math
│• ${pfx}benarsalah
│ •${pfx}susunkata
│• ${pfx}tebakemoji
│• ${pfx}caklontong
│• ${pfx}stopgame
│• ${pfx}truth
│• ${pfx}dare
│• ${pfx}cekkhodam <nama>
╰──────────────────────
╭──────────────
│*EKONOMI*
│• ${pfx}me
│• ${pfx}kerja
│• ${pfx}levelup
│• ${pfx}buytoken <jumlah>
│• ${pfx}transfer @user <jumlah>
│• ${pfx}rank
│• ${pfx}leaderboard
╰──────────────────────
╭──────────────
│*LAINNYA*
│• ${pfx}ai <pertanyaan>
│• ${pfx}react <emoji> (balas chat)
│• ${pfx}unreact (balas chat)
│• ${pfx}gamelink
╰──────────────────────
╭──────────────
│*OWNER*
│• ${pfx}setlevel / ${pfx}setmoney / ${pfx}settoken @user <angka>
│• ${pfx}addsultan / ${pfx}delsultan @user
│• ${pfx}listsultan
│• ${pfx}bc <pesan>
╰──────────────────────
`.trim();

async function handleMessage(sock, msg) {
  try {
    if (!msg.message || msg.key.fromMe) return;

    const from = msg.key.remoteJid;
    const isGroup = from.endsWith("@g.us");
    const sender = isGroup ? msg.key.participant : from;
    const text = getText(msg).trim();
    const pfx = config.prefix;

    if (!isGroup) {
      const isOwnerDM = await isOwner(sock, false, from, sender);
      if (!isOwnerDM) {await sock.sendMessage(from, {
          text: "🚫 Bot ini jangan di-PM ya. Kalau mau pakai fiturnya, invite bot ke grup aja 🙏",
        });
        try {
          await sock.updateBlockStatus(sender, "block");
        } catch (e) {}
        return;
      }
    }

    if (isGroup) {
      const mentioned =
        msg.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
      const quotedForAfk = getQuoted(msg);
      const quotedSender = msg.message?.extendedTextMessage?.contextInfo?.participant;
      const checkTargets = [...mentioned, quotedSender].filter(Boolean);

      for (const target of checkTargets) {
        const afk = db.getAfk(target);
        if (afk) {
          const durasi = formatDuration(Date.now() - afk.time);
          await sock.sendMessage(from, {
            text: `@${target.split("@")[0]} sedang AFK sejak ${durasi} lalu.\nAlasan: ${afk.reason}`,
            mentions: [target],
          });
          break;
        }
      }

      if (db.getAfk(sender) && !text.startsWith(pfx + "afk")) {
        db.removeAfk(sender);
        await sock.sendMessage(from, {
          text: `Welcome back @${sender.split("@")[0]}, status AFK kamu sudah dihapus.`,
          mentions: [sender],
        });
      }
    }

    if (isGroup && !text.startsWith(pfx)) {
      const linkRegex = /(chat\.whatsapp\.com|https?:\/\/)/i;
      if (db.isAntilinkActive(from) && linkRegex.test(text)) {
        const senderIsAdmin = await isSenderAdmin(sock, from, sender);
        const botCanKick = await isBotAdmin(sock, from);
        if (!senderIsAdmin && botCanKick) {
          await sock.sendMessage(from, {
            text: `🔗 Link terdeteksi! @${sender.split("@")[0]} dikeluarkan otomatis (antilink aktif).`,
            mentions: [sender],
          });
          await sock.groupParticipantsUpdate(from, [sender], "remove");
          return;
        }
      }
    }

    if (isGroup && !text.startsWith(pfx) && text.trim()) {
      const activeTebak = tebak.getActiveGame(from);
      if (activeTebak) {
        const result = tebak.checkAnswer(from, text);
        if (result && result.correct) {
          const winnerName = msg.pushName || "Player";
          const dataWin = economy.getUser(sender);
          economy.updateUser(sender, { money: (dataWin.money || 0) + result.prize, name: winnerName });
          await sock.sendMessage(from, {
            text: `✅ Bener! Jawabannya *${result.answer}*.\n${winnerName} dapet Rp${result.prize.toLocaleString("id-ID")}!`,
          });
          return;
        } else if (result && result.hint) {
          await sock.sendMessage(from, { text: result.hint });
          return;
        }
      }
    }

    if (!text.startsWith(pfx)) return;

    const args = text.slice(pfx.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();
    const fullArgs = args.join(" ");
    const quoted = getQuoted(msg);
    const mentionedInMsg =
      msg.message.extendedTextMessage?.contextInfo?.mentionedJid || [];

    const senderIsOwner = await isOwner(sock, isGroup, from, sender);

    if (["sleep", "self", "public"].includes(command)) {
      if (!senderIsOwner) {
        await sock.sendMessage(from, { text: "Cuma owner yang boleh ganti mode bot." }, { quoted: msg });
        return;
      }
      db.setMode(command);
      const label =
        command === "sleep"
          ? "😴 Sleep (bot tidak merespon siapa pun kecuali owner)"
          : command === "self"
          ? "🔒 Self (cuma owner yang bisa pakai bot)"
          : "🌐 Public (semua orang bisa pakai bot)";
      await sock.sendMessage(from, { text: `Mode bot diganti ke:\n${label}` }, { quoted: msg });
      return;
    }

    const currentMode = db.getMode();
    if (!senderIsOwner) {
      if (currentMode === "sleep") return;
      if (currentMode === "self") return;
    }

    switch (command) {

      case "menu":
      case "help": {
        const menuText = buildMenu(pfx, { name: msg.pushName, uptime: formatDuration(Date.now() - startTime) });
        const mediaDir = path.join(__dirname, "media");
        fs.mkdirSync(mediaDir, { recursive: true });

        const imgPath = path.join(mediaDir, "menu.jpg");
        const audioPath = path.join(mediaDir, "honeybee.mp3");if (fs.existsSync(imgPath)) {
          await sock.sendMessage(from, { image: fs.readFileSync(imgPath), caption: menuText }, { quoted: msg });
        } else {
          await sock.sendMessage(from, { text: menuText }, { quoted: msg });
        }

        try {
          if (!fs.existsSync(audioPath)) {
            const video = await searchYoutube("honeybee");
            if (video) {
              const buffer = await downloadYoutubeAudio(video.url);
              fs.writeFileSync(audioPath, buffer);
            }
          }
          if (fs.existsSync(audioPath)) {
            await sock.sendMessage(from, {
              audio: fs.readFileSync(audioPath),
              mimetype: "audio/mp4",
              fileName: "honeybee.mp3",
            });
          }
        } catch (e) {
          // gagal ambil lagu, biarin aja, menu teks/gambar tetap udah kekirim
        }
        break;
      }

      case "robloxstalk":
      case "rbstalk":
      case "stalkroblox": {
        if (!fullArgs) {
          await sock.sendMessage(from, { text: "Contoh: " + pfx + "robloxstalk username" }, { quoted: msg });
          break;
        }
        const waitRb = cooldownLeft("rb:" + sender, 8000);
        if (waitRb) {
          await sock.sendMessage(from, { text: "⏳ Tunggu " + waitRb + " detik dulu ya." }, { quoted: msg });
          break;
        }
        try {
          await sock.sendMessage(from, { text: "🔍 Mencari akun Roblox..." }, { quoted: msg });
          const rb = await stalkRoblox(fullArgs);
          const parts = formatRobloxParts(rb);
          const avaBuf = rb.avatar ? await fetchAvatarBuffer(rb.avatar) : null;
          let imgOk = false;
          if (avaBuf) {
            try {
              await sock.sendMessage(from, { image: avaBuf, caption: parts.main }, { quoted: msg });
              imgOk = true;
            } catch (_) {}
          }
          if (imgOk) await sock.sendMessage(from, { text: parts.extra });
          else await sock.sendMessage(from, { text: parts.main + "\n\n" + parts.extra }, { quoted: msg });
        } catch (e) {
          await sock.sendMessage(from, { text: "❌ " + e.message }, { quoted: msg });
        }
        break;
      }

      case "mlstalk":
      case "mlbb": {
        await runGameCheck({ sock, from, msg, sender, pfx, game: "ml", args: fullArgs });
        break;
      }

      case "ffstalk": {
        await runGameCheck({ sock, from, msg, sender, pfx, game: "ff", args: fullArgs });
        break;
      }

      case "ping": {
        const start = Date.now();
        await sock.sendMessage(from, { text: "Pinging..." }, { quoted: msg });
        const latency = Date.now() - start;
        await sock.sendMessage(from, {
          text: `🏓 Pong! ${latency}ms\nUptime: ${formatDuration(Date.now() - startTime)}`,
        });
        break;
      }

      case "owner": {
        await sock.sendMessage(
          from,
          {
            contacts: {
              displayName: "Owner Bot",
              contacts: [
                {
                  vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:Owner Bot\nTEL;type=CELL;type=VOICE;waid=${config.ownerNumber}:+${config.ownerNumber}\nEND:VCARD`,
                },
              ],
            },
          },
          { quoted: msg }
        );
        break;
      }

      case "afk": {
        db.setAfk(sender, fullArgs || "Tidak ada alasan");
        await sock.sendMessage(from, {
          text: `✅ Status AFK diset untuk @${sender.split("@")[0]}\nAlasan: ${fullArgs || "Tidak ada alasan"}`,
          mentions: [sender],
        }, { quoted: msg });
        break;
      }

      case "brat": {
        if (!fullArgs) {
          await sock.sendMessage(from, { text: `Contoh: ${pfx}brat teks kamu di sini` }, { quoted: msg });
          break;
        }
        const img = await generateBratImage(fullArgs);
        const stickerBuf = await bufferToSticker(img, false);
        await sock.sendMessage(from, { sticker: stickerBuf }, { quoted: msg });
        break;
      }

      case "fakecall": {
        // format: .fakecall nama | durasi | jam | status
        const parts = (fullArgs || "").split("|").map((p) => p.trim());
        const targetName = parts[0] || msg.pushName || "Unknown";
        const targetDuration = parts[1] || "00:00";
        const targetTime = parts[2] || "";
        const targetStatus = parts[3] || "";

        let avatarBuffer = null;

        const mediaSource = quoted && quoted.message && quoted.message.imageMessage ? quoted : (msg.message && msg.message.imageMessage ? msg : null);
        if (mediaSource) {
          try {
            avatarBuffer = await downloadMediaMessage(mediaSource, "buffer", {});
          } catch (e) {
            avatarBuffer = null;
          }
        }

        if (!avatarBuffer) {
          const picTargetJid = mentionedInMsg[0] || sender;
          try {
            const ppUrl = await sock.profilePictureUrl(picTargetJid, "image");
            const resp = await axios.get(ppUrl, { responseType: "arraybuffer", timeout: 15000 });
            avatarBuffer = Buffer.from(resp.data);
          } catch (e) {
            avatarBuffer = null;
          }
        }

        try {
          const { generateFakeCallImage } = require("./lib/fakecall");
          const img = await generateFakeCallImage({
            name: targetName,
            duration: targetDuration,
            time: targetTime,
            status: targetStatus,
            avatarBuffer,
          });
          await sock.sendMessage(from, { image: img, caption: "📞 Sedang menelepon " + targetName + "..." }, { quoted: msg });
        } catch (e) {
          console.error("[fakecall] gagal:", e.message);
          await sock.sendMessage(from, { text: "❌ Gagal fakecall: " + e.message }, { quoted: msg });
        }
        break;
      }

      case "me": {
        const targetJid = mentionedInMsg[0] || sender;
        const targetIsOwner = await isOwner(sock, isGroup, from, targetJid);
        const data = economy.getUser(targetJid);
        const levelText = targetIsOwner ? "MAX 👑" : data.level;
        const tokenText = targetIsOwner ? "∞" : data.token;
        const moneyText = "Rp" + (data.money || 0).toLocaleString("id-ID");

        const caption = `👤 *Profile*\n\nToken: ${tokenText}\nLevel: ${levelText}\nMoney: ${moneyText}`;

        let avatarBuffer = null;
        try {
          const ppUrl = await sock.profilePictureUrl(targetJid, "image");
          const resp = await axios.get(ppUrl, { responseType: "arraybuffer", timeout: 15000 });
          avatarBuffer = Buffer.from(resp.data);
        } catch (e) {
          avatarBuffer = null;
        }

        if (avatarBuffer) {
          await sock.sendMessage(from, { image: avatarBuffer, caption }, { quoted: msg });
        } else {
          await sock.sendMessage(from, { text: caption }, { quoted: msg });
        }
        break;
      }

      case "kerja": {
        const lastKerja = kerjaCooldown.get(sender) || 0;
        const sinceLastKerja = Date.now() - lastKerja;
        if (sinceLastKerja < KERJA_COOLDOWN_MS) {
          const sisaDetik = Math.ceil((KERJA_COOLDOWN_MS - sinceLastKerja) / 1000);
          await sock.sendMessage(from, { text: `⏳ Sabar dulu, tunggu ${sisaDetik} detik lagi buat kerja.` }, { quoted: msg });
          break;
        }
        kerjaCooldown.set(sender, Date.now());

        if (senderIsOwner) {
          const gajiOwner = (Math.floor(Math.random() * 10000) + 5000) * OWNER_EFFECTIVE_LEVEL;
          const dataOwner = economy.getUser(sender);
          economy.updateUser(sender, { money: (dataOwner.money || 0) + gajiOwner });
          await sock.sendMessage(from, {
            text: `👑 Owner kerja (level MAX, token unlimited)\n💵 Dapat Rp${gajiOwner.toLocaleString("id-ID")}`,
          }, { quoted: msg });
          break;
        }

        const dataKerja = economy.getUser(sender);
        if (dataKerja.token <= 0) {
          await sock.sendMessage(from, {
            text: "❌ Token kamu habis hari ini. Tunggu reset besok atau beli token pakai " + pfx + "buytoken.",
          }, { quoted: msg });
          break;
        }

        const gaji = (Math.floor(Math.random() * 10000) + 5000) * dataKerja.level;
        const newMoney = (dataKerja.money || 0) + gaji;
        const newToken = dataKerja.token - 1;
        let leveledUp = false;
        let newLevel = dataKerja.level;
        if (Math.random() < 0.15 && dataKerja.level < MAX_LEVEL) {
          leveledUp = true;
          newLevel = dataKerja.level + 1;
        }
        economy.updateUser(sender, { money: newMoney, token: newToken, level: newLevel });

        let resultText = `💼 Kamu kerja dan dapat Rp${gaji.toLocaleString("id-ID")}\n🎫 Sisa token: ${newToken}`;
        if (leveledUp) resultText += `\n🎉 Selamat! Level naik jadi ${newLevel}!`;
        await sock.sendMessage(from, { text: resultText }, { quoted: msg });
        break;
      }

      case "levelup": {
        if (senderIsOwner) {
          await sock.sendMessage(from, { text: "👑 Kamu owner, level kamu udah MAX." }, { quoted: msg });
          break;
        }
        const dataLvl = economy.getUser(sender);
        if (dataLvl.level >= MAX_LEVEL) {
          await sock.sendMessage(from, { text: `Level kamu udah maksimal (${MAX_LEVEL}).` }, { quoted: msg });
          break;
        }
        const cost = dataLvl.level * 100000;
        if ((dataLvl.money || 0) < cost) {
          await sock.sendMessage(from, {
            text: `❌ Duit kamu kurang. Butuh Rp${cost.toLocaleString("id-ID")} buat naik ke level ${dataLvl.level + 1}.`,
          }, { quoted: msg });
          break;
        }
        economy.updateUser(sender, { money: dataLvl.money - cost, level: dataLvl.level + 1 });
        await sock.sendMessage(from, {
          text: `🎉 Level naik jadi ${dataLvl.level + 1}! Sisa duit: Rp${(dataLvl.money - cost).toLocaleString("id-ID")}`,
        }, { quoted: msg });
        break;
      }

      case "buytoken": {
        if (senderIsOwner) {
          await sock.sendMessage(from, { text: "👑 Kamu owner, token kamu udah unlimited." }, { quoted: msg });
          break;
        }
        const jumlah = parseInt(fullArgs, 10);
        if (!jumlah || jumlah <= 0) {
          await sock.sendMessage(from, { text: `Contoh: ${pfx}buytoken 5` }, { quoted: msg });
          break;
        }
        const hargaPerToken = 5000;
        const totalHarga = jumlah * hargaPerToken;
        const dataBeli = economy.getUser(sender);
        if ((dataBeli.money || 0) < totalHarga) {
          await sock.sendMessage(from, {
            text: `❌ Duit kamu kurang. Butuh Rp${totalHarga.toLocaleString("id-ID")} buat beli ${jumlah} token.`,
          }, { quoted: msg });
          break;
        }
        economy.updateUser(sender, {
          money: dataBeli.money - totalHarga,
          token: (dataBeli.token || 0) + jumlah,
        });
        await sock.sendMessage(from, {
          text: `✅ Berhasil beli ${jumlah} token seharga Rp${totalHarga.toLocaleString("id-ID")}.`,
        }, { quoted: msg });
        break;
      }

      case "setlevel":
      case "setmoney":
      case "settoken": {
        const senderIsSultan = db.isSultan(sender);
        if (!senderIsOwner && !senderIsSultan) {
          await sock.sendMessage(from, { text: "Cuma owner/sultan yang boleh pakai perintah ini." }, { quoted: msg });
          break;
        }
        const targetSet = mentionedInMsg[0] || quoted?.key?.participant || sender;

        if (!senderIsOwner && senderIsSultan && targetSet === sender) {
          await sock.sendMessage(from, { text: "Sultan cuma bisa ngeset orang lain, nggak bisa ngeset diri sendiri." }, { quoted: msg });
          break;
        }

        const partsSet = fullArgs.trim().split(/\s+/);
        const valueSet = parseInt(partsSet[partsSet.length - 1], 10);
        if (isNaN(valueSet)) {
          await sock.sendMessage(from, { text: `Contoh: ${pfx}${command} @user 5` }, { quoted: msg });
          break;
        }
        const field = command === "setlevel" ? "level" : command === "setmoney" ? "money" : "token";
        economy.updateUser(targetSet, { [field]: valueSet });
        await sock.sendMessage(from, {
          text: `✅ ${field} @${targetSet.split("@")[0]} diset jadi ${valueSet}`,
          mentions: [targetSet],
        }, { quoted: msg });
        break;
      }

      case "addsultan":
      case "delsultan": {
        if (!senderIsOwner) {
          await sock.sendMessage(from, { text: "Cuma owner yang boleh atur sultan." }, { quoted: msg });
          break;
        }
        const targetSultan = mentionedInMsg[0] || quoted?.key?.participant;
        if (!targetSultan) {
          await sock.sendMessage(from, { text: `Tag/reply orangnya, contoh: ${pfx}${command} @user` }, { quoted: msg });
          break;
        }
        if (command === "addsultan") {
          db.addSultan(targetSultan);
          await sock.sendMessage(from, {
            text: `👑 @${targetSultan.split("@")[0]} sekarang jadi Sultan.`,
            mentions: [targetSultan],
          }, { quoted: msg });
        } else {
          db.removeSultan(targetSultan);
          await sock.sendMessage(from, {
            text: `✅ @${targetSultan.split("@")[0]} udah bukan Sultan lagi.`,
            mentions: [targetSultan],
          }, { quoted: msg });
        }
        break;
      }

      case "listsultan": {
        const list = db.getSultanList();
        if (list.length === 0) {
          await sock.sendMessage(from, { text: "Belum ada Sultan sama sekali." }, { quoted: msg });
          break;
        }
        await sock.sendMessage(from, {
          text: `👑 *Daftar Sultan*\n\n${list.map((j) => "@" + j.split("@")[0]).join("\n")}`,
          mentions: list,
        }, { quoted: msg });
        break;
      }

      case "ular": {
        if (!isGroup) {
          await sock.sendMessage(from, { text: "Fitur ular tangga cuma bisa dipakai di grup." }, { quoted: msg });
          break;
        }
        const [sub, ...subArgsArr] = fullArgs.trim().split(/\s+/);
        const subArgs = subArgsArr.join(" ");
        const playerName = msg.pushName || "Player";

        if (sub === "start") {
          const existing = ular.getGame(from);
          if (existing && existing.status !== "finished") {
            await sock.sendMessage(from, { text: `Masih ada game yang jalan/nunggu. Ketik ${pfx}ular batal dulu kalau mau mulai baru.` }, { quoted: msg });
            break;
          }
          const mode = subArgs.toLowerCase() === "multi" ? "multi" : "solo";
          ular.createGame(from, mode, sender, playerName);
          if (mode === "solo") {
            const game = ular.getGame(from);
            const img = await ular.generateBoardImage(game.players);
            await sock.sendMessage(from, {
              image: img,
              caption: `🐍 Ular Tangga solo dimulai!\nKetik ${pfx}kocok buat lempar dadu.`,
            }, { quoted: msg });
          } else {
            await sock.sendMessage(from, {
              text: `🐍 Lobby ular tangga dibuka oleh ${playerName}!\nKetik ${pfx}ular join buat gabung.\nKalau udah cukup, ${playerName} ketik ${pfx}ular begin buat mulai.`,
            }, { quoted: msg });
          }
          break;
        }

        if (sub === "join") {
          const game = ular.joinGame(from, sender, playerName);
          if (!game) {
            await sock.sendMessage(from, { text: "Nggak ada lobby yang lagi dibuka. Mulai dulu pakai " + pfx + "ular start multi" }, { quoted: msg });
            break;
          }
          const names = game.players.map((p) => p.name).join(", ");
          await sock.sendMessage(from, { text: `✅ ${playerName} gabung!\nPemain sekarang: ${names}` }, { quoted: msg });
          break;
        }

        if (sub === "begin") {
          const gameBefore = ular.getGame(from);
          if (!gameBefore || gameBefore.status !== "waiting") {
            await sock.sendMessage(from, { text: "Nggak ada lobby yang lagi nunggu buat dimulai." }, { quoted: msg });
            break;
          }
          if (gameBefore.startedBy !== sender && !senderIsOwner) {
            await sock.sendMessage(from, { text: "Cuma yang buka lobby (atau owner) yang boleh mulai game." }, { quoted: msg });
            break;
          }
          if (gameBefore.players.length < 2) {
            await sock.sendMessage(from, { text: `Minimal 2 pemain buat mode multi. Ajak temen ketik ${pfx}ular join dulu, atau pakai ${pfx}ular start solo kalau mau sendirian.` }, { quoted: msg });
            break;
          }
          const game = ular.beginGame(from);
          const img = await ular.generateBoardImage(game.players);
          await sock.sendMessage(from, {
            image: img,
            caption: `🐍 Game dimulai! Urutan main: ${game.players.map((p) => p.name).join(" ➜ ")}\n\nGiliran pertama: *${game.players[0].name}*, ketik ${pfx}kocok`,
          }, { quoted: msg });
          break;
        }

        if (sub === "status") {
          const game = ular.getGame(from);
          if (!game) {
            await sock.sendMessage(from, { text: "Nggak ada game aktif di grup ini." }, { quoted: msg });
            break;
          }
          const img = await ular.generateBoardImage(game.players);
          const posText = game.players.map((p) => `${p.name}: ${p.position}`).join("\n");
          let statusText = `📋 Status game (${game.mode}):\n${posText}`;
          if (game.mode === "multi" && game.status === "playing") {
            statusText += `\n\nGiliran: ${game.players[game.turnIndex].name}`;
          }
          await sock.sendMessage(from, { image: img, caption: statusText }, { quoted: msg });
          break;
        }

        if (sub === "batal" || sub === "cancel") {
          const game = ular.getGame(from);
          if (!game) {
            await sock.sendMessage(from, { text: "Nggak ada game buat dibatalin." }, { quoted: msg });
            break;
          }
          if (game.startedBy !== sender && !senderIsOwner) {
            await sock.sendMessage(from, { text: "Cuma yang buka game (atau owner) yang boleh batalin." }, { quoted: msg });
            break;
          }
          ular.cancelGame(from);
          await sock.sendMessage(from, { text: "🚫 Game ular tangga dibatalin." }, { quoted: msg });
          break;
        }

        if (sub === "kocok") {
          await handleUlarRoll(sock, msg, from, sender);
          break;
        }

        await sock.sendMessage(from, {
          text: `Contoh: ${pfx}ular start solo | ${pfx}ular start multi | ${pfx}ular join | ${pfx}ular begin | ${pfx}ular status | ${pfx}ular batal`,
        }, { quoted: msg });
        break;
      }

      case "kocok": {
        if (!isGroup) {
          await sock.sendMessage(from, { text: "Fitur ular tangga cuma bisa dipakai di grup." }, { quoted: msg });
          break;
        }
        await handleUlarRoll(sock, msg, from, sender);
        break;
      }

      case "tebakangka":
      case "math":
      case "benarsalah":
      case "susunkata":
      case "tebakemoji":
      case "caklontong": {
        if (!isGroup) {
          await sock.sendMessage(from, { text: "Game tebak-tebakan cuma bisa di grup." }, { quoted: msg });
          break;
        }
        const game = tebak.startGame(from, command);
        if (!game) {
          await sock.sendMessage(from, { text: `Masih ada game aktif. Jawab dulu atau ketik ${pfx}stopgame.` }, { quoted: msg });
          break;
        }
        await sock.sendMessage(from, { text: `🎲 ${game.question}\n\n💰 Hadiah: Rp${game.prize.toLocaleString("id-ID")}` }, { quoted: msg });
        break;
      }

      case "stopgame": {
        if (!isGroup) {
          await sock.sendMessage(from, { text: "Fitur ini cuma bisa di grup." }, { quoted: msg });
          break;
        }
        const activeCheck = tebak.getActiveGame(from);
        if (!activeCheck) {
          await sock.sendMessage(from, { text: "Nggak ada game yang lagi jalan." }, { quoted: msg });
          break;
        }
        const isAdminCheck = await isSenderAdmin(sock, from, sender);
        if (!isAdminCheck && !senderIsOwner) {
          await sock.sendMessage(from, { text: "Cuma admin/owner yang boleh stop game." }, { quoted: msg });
          break;
        }
        tebak.stopGame(from);
        await sock.sendMessage(from, { text: "🛑 Game dihentikan." }, { quoted: msg });
        break;
      }

      case "truth": {
        await sock.sendMessage(from, { text: `🤔 *Truth:*\n${tebak.getTruth()}` }, { quoted: msg });
        break;
      }

      case "dare": {
        await sock.sendMessage(from, { text: `🔥 *Dare:*\n${tebak.getDare()}` }, { quoted: msg });
        break;
      }

      case "cekkhodam": {
        const namaKhodam = fullArgs || msg.pushName || "Kamu";
        await sock.sendMessage(from, { text: tebak.getKhodam(namaKhodam) }, { quoted: msg });
        break;
      }

      case "rank": {
        const targetRank = mentionedInMsg[0] || sender;
        const dataRank = economy.getUser(targetRank);
        const rankInfo = economy.getRank(targetRank);
        await sock.sendMessage(from, {
          text: `📊 Rank: #${rankInfo.rank || "-"} dari ${rankInfo.total} orang\nMoney: Rp${(dataRank.money || 0).toLocaleString("id-ID")}`,
          mentions: [targetRank],
        }, { quoted: msg });
        break;
      }

      case "leaderboard":
      case "toplocal":
      case "topbalance": {
        const top = economy.getLeaderboard(10);
        if (top.length === 0) {
          await sock.sendMessage(from, { text: "Belum ada data ekonomi sama sekali." }, { quoted: msg });
          break;
        }
        const lines = top.map((u, i) => {
          const label = u.name || ("@" + u.jid.split("@")[0]);
          return `${i + 1}. ${label} - Rp${(u.money || 0).toLocaleString("id-ID")}`;
        });
        await sock.sendMessage(from, { text: `🏆 *Top 10 Terkaya*\n\n${lines.join("\n")}` }, { quoted: msg });
        break;
      }

      case "transfer": {
        const targetTransfer = mentionedInMsg[0] || quoted?.key?.participant;
        if (!targetTransfer) {
          await sock.sendMessage(from, { text: `Contoh: ${pfx}transfer @user 50000` }, { quoted: msg });
          break;
        }
        if (targetTransfer === sender) {
          await sock.sendMessage(from, { text: "Nggak bisa transfer ke diri sendiri." }, { quoted: msg });
          break;
        }
        const partsTransfer = fullArgs.trim().split(/\s+/);
        const amountTransfer = parseInt(partsTransfer[partsTransfer.length - 1], 10);
        if (!amountTransfer || amountTransfer <= 0) {
          await sock.sendMessage(from, { text: `Contoh: ${pfx}transfer @user 50000` }, { quoted: msg });
          break;
        }
        const senderData = economy.getUser(sender);
        if ((senderData.money || 0) < amountTransfer) {
          await sock.sendMessage(from, { text: "Duit kamu nggak cukup." }, { quoted: msg });
          break;
        }
        const targetData = economy.getUser(targetTransfer);
        economy.updateUser(sender, { money: senderData.money - amountTransfer });
        economy.updateUser(targetTransfer, { money: (targetData.money || 0) + amountTransfer });
        await sock.sendMessage(from, {
          text: `✅ Berhasil transfer Rp${amountTransfer.toLocaleString("id-ID")} ke @${targetTransfer.split("@")[0]}`,
          mentions: [targetTransfer],
        }, { quoted: msg });
        break;
      }

      case "react": {
        if (!quoted) {
          await sock.sendMessage(from, { text: `Reply pesan yang mau di-react, contoh: ${pfx}react 🔥` }, { quoted: msg });
          break;
        }
        const emoji = fullArgs.trim() || "❤️";
        await sock.sendMessage(from, { react: { text: emoji, key: quoted.key } });
        break;
      }

      case "unreact": {
        if (!quoted) {
          await sock.sendMessage(from, { text: "Reply pesan yang reaksinya mau dihapus." }, { quoted: msg });
          break;
        }
        await sock.sendMessage(from, { react: { text: "", key: quoted.key } });
        break;
      }

      case "ai": {
        if (!fullArgs) {
          await sock.sendMessage(from, { text: `Contoh: ${pfx}ai jelasin cara kerja fotosintesis` }, { quoted: msg });
          break;
        }
        try {
          const answer = await askGemini(fullArgs);
          await sock.sendMessage(from, { text: `🤖 ${answer}` }, { quoted: msg });
        } catch (e) {
          await sock.sendMessage(from, { text: "❌ Gagal minta jawaban AI: " + e.message }, { quoted: msg });
        }
        break;
      }

      case "ifake":
      case "iqc2": {
        if (!fullArgs) {
          await sock.sendMessage(from, {
            text:
              "Contoh:\n" +
              pfx + "ifake mau call?\n" +
              pfx + "ifake mau call? | 14:00\n" +
              pfx + "ifake gas nanti malem 😂 | 21.30 | out\n\n" +
              "Opsi ketiga: in (putih, default) / out (hijau, centang biru)"
          }, { quoted: msg });
          break;
        }
        try {
          const parts = fullArgs.split("|").map((p) => p.trim());
          const text = parts[0] || "";
          let timeArg = "";
          let side = "in";
          for (const p of parts.slice(1)) {
            if (/^(out|keluar|kanan|hijau)$/i.test(p)) side = "out";
            else if (/^(in|masuk|kiri|putih)$/i.test(p)) side = "in";
            else if (p) timeArg = p;
          }
          if (!text) {
            await sock.sendMessage(from, { text: "Teks kosong." }, { quoted: msg });
            break;
          }

          await sock.sendMessage(from, { text: "⏳ Bikin tampilan iPhone..." }, { quoted: msg });

          const { renderIosQuote, legacyApiQuote } = require("./lib/iosquote");
          let buf;
          try {
            buf = await renderIosQuote({ text, time: timeArg, side });
          } catch (err) {
            console.error("[ifake] render lokal gagal, pakai API lama:", err.message);
            buf = await legacyApiQuote(text, timeArg);
          }

          await sock.sendMessage(from, { image: buf, caption: "✅ iFake" }, { quoted: msg });
        } catch (e) {
          await sock.sendMessage(from, { text: "❌ Gagal ifake: " + e.message }, { quoted: msg });
        }
        break;
      }


      case "wq":
      case "wqn": {
        // Windows Quoted (gambar asli, cuma teks yang digenerate)
        // .wq teks             -> karakter acak
        // .wq teks | 2         -> karakter nomor 2
        // .wq teks | polos     -> tanpa karakter (alias: .wqn teks)
        // balas chat + .wq     -> pakai teks chat yang dibalas
        const wqParts = fullArgs.split("|").map((p) => p.trim());
        let wqText = wqParts[0] || "";
        let wqMan = command !== "wqn";
        let wqChar;
        for (const o of wqParts.slice(1)) {
          if (/^(polos|nomen|noman|tanpa|tanpaorang|tanpa orang|no)$/i.test(o)) wqMan = false;
          else if (/^\d+$/.test(o)) wqChar = parseInt(o, 10);
        }
        if (!wqText) {
          const qm = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
          wqText = (qm && (qm.conversation || qm.extendedTextMessage?.text || qm.imageMessage?.caption || qm.videoMessage?.caption)) || "";
        }
        if (!wqText.trim()) {
          await sock.sendMessage(from, {
            text:
              "Contoh:\n" +
              pfx + "wq just friend kok cemburu 🤓\n" +
              pfx + "wq just friend kok cemburu | 2\n" +
              pfx + "wq just friend kok cemburu | polos\n\n" +
              "Karakter dipilih acak. Tambah | angka buat pilih karakter tertentu, atau | polos (atau " + pfx + "wqn) buat tanpa karakter. Bisa juga balas chat terus ketik " + pfx + "wq.",
          }, { quoted: msg });
          break;
        }
        try {
          const { renderWq } = require("./lib/wq");
          const buf = await renderWq({ text: wqText, man: wqMan, char: wqChar });
          await sock.sendMessage(from, { image: buf, caption: "✅ WQ" }, { quoted: msg });
        } catch (e) {
          console.error("[wq]", e);
          await sock.sendMessage(from, { text: "❌ Gagal bikin wq: " + e.message }, { quoted: msg });
        }
        break;
      }

      case "fakeml": {
        // Fake lobby Mobile Legends
        // .fakeml nama | rank | ping     (PP: kirim/balas gambar, kalau tidak -> foto profil WA)
        const { generateFakeMl, resolveRank, RANKS } = require("./lib/fakeml");
        const fmParts = (fullArgs || "").split("|").map((p) => p.trim());
        const fmName = fmParts[0] || msg.pushName || "Player";
        const fmRank = fmParts[1] || "";
        const fmPing = fmParts[2] || "";
        if (fmRank && !resolveRank(fmRank)) {
          await sock.sendMessage(from, {
            text:
              'Rank "' + fmRank + '" nggak dikenal.\n\nPilihan rank:\n' +
              RANKS.map((r, i) => (i + 1) + ". " + r.label).join("\n") +
              "\n\nContoh: " + pfx + "fakeml Lloyd | mythic | 20\n(bisa pakai angka atau nama rank)",
          }, { quoted: msg });
          break;
        }

        let fmAvatar = null;
        const fmMedia = quoted && quoted.message && quoted.message.imageMessage ? quoted : (msg.message && msg.message.imageMessage ? msg : null);
        if (fmMedia) {
          try { fmAvatar = await downloadMediaMessage(fmMedia, "buffer", {}); } catch (e) { fmAvatar = null; }
        }
        if (!fmAvatar) {
          const fmPicJid = mentionedInMsg[0] || sender;
          try {
            const ppUrl = await sock.profilePictureUrl(fmPicJid, "image");
            const resp = await axios.get(ppUrl, { responseType: "arraybuffer", timeout: 15000 });
            fmAvatar = Buffer.from(resp.data);
          } catch (e) { fmAvatar = null; }
        }

        try {
          const img = await generateFakeMl({ name: fmName, rank: fmRank || "mythic", ping: fmPing, avatarBuffer: fmAvatar });
          await sock.sendMessage(from, { image: img, caption: "✅ Fake ML" }, { quoted: msg });
        } catch (e) {
          console.error("[fakeml]", e);
          await sock.sendMessage(from, { text: "❌ Gagal bikin fakeml: " + e.message }, { quoted: msg });
        }
        break;
      }

      case "iqc": {
        if (!fullArgs) {
          await sock.sendMessage(from, {
            text: `Contoh:\n${pfx}iqc Halo bro | 20:00 | 👍❤️\n\nAtau multi-bubble:\n${pfx}iqc Halo--- Lagi apa? | 20:00`,
          }, { quoted: msg });
          break;
        }

        const parts = fullArgs.split("|").map((p) => p.trim());
        const rawText = parts[0] || "";
        const timeArg = parts[1] || (() => {
          const now = new Date();
          return now.getHours().toString().padStart(2, "0") + ":" + now.getMinutes().toString().padStart(2, "0");
        })();
        const reactionArg = parts[2] || "";

        const texts = rawText.split("---").map((t) => t.trim()).filter((t) => t.length > 0);
        if (texts.length === 0) {
          await sock.sendMessage(from, { text: "Teksnya kosong, isi dulu ya." }, { quoted: msg });
          break;
        }

        const reactions = parseReactions(reactionArg);

        try {
          const img = await generateIqcImage({ texts, time: timeArg, reactions });
          await sock.sendMessage(from, { image: img }, { quoted: msg });
        } catch (e) {
          await sock.sendMessage(from, { text: "Gagal bikin IQC: " + e.message }, { quoted: msg });
        }
        break;
      }

      case "sticker":
      case "s": {
        const target = quoted || msg;
        const type = Object.keys(target.message)[0];
        if (!["imageMessage", "videoMessage"].includes(type)) {
          await sock.sendMessage(from, { text: "Kirim/reply gambar atau video singkat dengan caption .sticker" }, { quoted: msg });
          break;
        }
        const buffer = await downloadMediaMessage(target, "buffer", {});
        const stickerBuf = await bufferToSticker(buffer, type === "videoMessage");
        await sock.sendMessage(from, { sticker: stickerBuf }, { quoted: msg });
        break;
      }

      case "toimg": {
        if (!quoted || !quoted.message.stickerMessage) {
          await sock.sendMessage(from, { text: `Reply sticker dengan caption ${pfx}toimg` }, { quoted: msg });
          break;
        }
        const buffer = await downloadMediaMessage(quoted, "buffer", {});
        await sock.sendMessage(from, { image: buffer }, { quoted: msg });
        break;
      }

      case "quotly": {
        if (!quoted) {
          await sock.sendMessage(from, { text: `Reply pesan teks dengan caption ${pfx}quotly` }, { quoted: msg });
          break;
        }
        const quotedText = getText(quoted);
        const senderName = msg.pushName || "User";
        try {
          const imgBuf = await generateQuotly({ text: quotedText, name: senderName });
          const stickerBuf = await bufferToSticker(imgBuf, false);
          await sock.sendMessage(from, { sticker: stickerBuf }, { quoted: msg });
        } catch (e) {
          await sock.sendMessage(from, { text: "Gagal bikin quotly: " + e.message }, { quoted: msg });
        }
        break;
      }


      case "ytmp4": {
        if (!fullArgs) {
          await sock.sendMessage(from, { text: `Contoh: ${pfx}ytmp4 judul/link video` }, { quoted: msg });
          break;
        }
        await sock.sendMessage(from, {
          text: "ytmp4 lagi maintenance, pakai play dulu",
	}, {quoted: msg });
	break;
       }


     case 'play':
        case 'ytplay': {
	  const reply = (t) => sock.sendMessage(from, { text: t }, { quoted: msg });
          const text = fullArgs;
          const m = msg;
	  const yts = require("yt-search");
	  const { exec } = require("child_process");
          if (!text) return reply('Contoh: .play taruh')

          await reply('⏳ Mencari lagu...')

          try {
            const search = await yts(text)
            const video = search.videos[0]
            if (!video) return reply('❌ Lagu tidak ditemukan')

            const title = video.title
            const url = video.url
            const duration = video.timestamp

            const info = '🎵 *Ditemukan!*\n\n📌 ' + title + '\n👤 ' + (video.author && video.author.name ? video.author.name : '-') + '\n⏱️ ' + duration + '\n\nSedang mengunduh...'
	    try {
 	      await sock.sendMessage(from, {
                image: { url: video.thumbnail || video.image },
                caption: info,
              }, { quoted: m })
            } catch (_) {
              await reply(info)
            }
            const fileName = 'yt_' + Date.now() + '.mp3'
            const filePath = path.join(__dirname, fileName)

            await new Promise((resolve, reject) => {
              const cmd = 'yt-dlp --js-runtimes deno --extractor-args "youtube:player_client=android" -x --audio-format mp3 --audio-quality 5 -o "' + filePath + '" "' + url + '"'
              console.log('Menjalankan yt-dlp...')
              exec(cmd, { timeout: 120000 }, (err, stdout, stderr) => {
                if (err) {
                  console.log('Error yt-dlp:', stderr || err.message)
                  reject(err)
                } else {
                  console.log('Download selesai')
                  resolve()
                }
              })
            })

            if (!fs.existsSync(filePath)) return reply('❌ Gagal membuat file audio')

            const stats = fs.statSync(filePath)
            if (stats.size < 10000) {
              fs.unlinkSync(filePath)
              return reply('❌ File audio rusak')
            }

            await sock.sendMessage(from, {
              audio: fs.readFileSync(filePath),
              mimetype: 'audio/mpeg',
              ptt: false
            }, { quoted: m })

            fs.unlinkSync(filePath)
            console.log('Berhasil dikirim & file dihapus')

          } catch (err) {
            console.error(err)
            await reply('❌ Gagal download lagu. Coba judul lain.')
          }
          break
        } 


      case "tiktok":
      case "tt": {
        if (!fullArgs) {
          await sock.sendMessage(from, { text: `Contoh: ${pfx}tiktok https://vt.tiktok.com/xxxx` }, { quoted: msg });
          break;
        }
        try {
          const result = await tiktokNoWatermark(fullArgs);
          await sock.sendMessage(
            from,
            {
              video: { url: result.videoUrl },
              caption: `🎬 ${result.title}\n👤 ${result.author}`,
            },
            { quoted: msg }
          );
        } catch (e) {
          await sock.sendMessage(from, { text: "Gagal download TikTok: " + e.message }, { quoted: msg });
        }
        break;
      }


      case "ttstalk":
      case "stalktiktok":
      case "tiktokstalk": {
        if (!fullArgs) {
          await sock.sendMessage(from, { text: `Contoh:\n${pfx}ttstalk charlidamelio\n${pfx}ttstalk https://www.tiktok.com/@charlidamelio` }, { quoted: msg });
          break;
        }
        try {
          await sock.sendMessage(from, { text: "🔎 Mengambil profil TikTok..." }, { quoted: msg });
          const info = await stalkTikTok(fullArgs);
          const caption = formatStalkCaption(info);
          if (info.avatar) {
            await sock.sendMessage(from, { image: { url: info.avatar }, caption }, { quoted: msg });
          } else {
            await sock.sendMessage(from, { text: caption }, { quoted: msg });
          }
        } catch (e) {
          await sock.sendMessage(from, { text: "❌ Gagal cek profil TikTok: " + e.message }, { quoted: msg });
        }
        break;
      }

      case "igstalk":
      case "stalkig":
      case "instagramstalk": {
        if (!fullArgs) {
          await sock.sendMessage(from, { text: `Contoh:\n${pfx}igstalk natgeo\n${pfx}igstalk https://www.instagram.com/natgeo` }, { quoted: msg });
          break;
        }
        try {
          await sock.sendMessage(from, { text: "🔎 Mengambil profil Instagram..." }, { quoted: msg });
          const info = await stalkInstagram(fullArgs);
          const caption = formatStalkCaption(info);
          if (info.avatar) {
            await sock.sendMessage(from, { image: { url: info.avatar }, caption }, { quoted: msg });
          } else {
            await sock.sendMessage(from, { text: caption }, { quoted: msg });
          }
        } catch (e) {
          await sock.sendMessage(from, { text: "❌ Gagal cek profil Instagram: " + e.message }, { quoted: msg });
        }
        break;
      }

      case "hidetag":
      case "kick":
      case "add":
      case "promote":
      case "demote":
      case "groupinfo":
      case "welcome":
      case "antilink":
      case "resetwarn": {
        if (!isGroup) {
          await sock.sendMessage(from, { text: "Perintah ini cuma bisa dipakai di grup." }, { quoted: msg });
          break;
        }
        await handleGroupCommand(sock, msg, {
          command,
          fullArgs,
          from,
          sender,
          mentionedInMsg,
          quoted,
        });
        break;
      }

      default:
        break;
    }
  } catch (err) {
    console.error("Handler error:", err);
  }
}

async function handleGroupCommand(sock, msg, ctx) {
  const { command, fullArgs, from, sender, mentionedInMsg, quoted } = ctx;
  const pfx = config.prefix;
  const senderIsAdmin = await isSenderAdmin(sock, from, sender);

  if (command === "hidetag") {
    if (!senderIsAdmin) {
      await sock.sendMessage(from, { text: "Cuma admin yang boleh pakai hidetag." }, { quoted: msg });
      return;
    }
    const metadata = await sock.groupMetadata(from);
    const participants = metadata.participants.map((p) => p.id);
    await sock.sendMessage(from, {
      text: fullArgs || "📢 Perhatian semuanya!",
      mentions: participants,
    });
    return;
  }

  if (command === "groupinfo") {
    const metadata = await sock.groupMetadata(from);
    const admins = metadata.participants.filter((p) => p.admin).map((p) => `@${p.id.split("@")[0]}`);
    await sock.sendMessage(from, {
      text: `*${metadata.subject}*\n📝 ${metadata.desc || "-"}\n👥 Member: ${metadata.participants.length}\n👑 Admin: ${admins.join(", ")}`,
      mentions: metadata.participants.filter((p) => p.admin).map((p) => p.id),
    }, { quoted: msg });
    return;
  }

  if (!senderIsAdmin) {
    await sock.sendMessage(from, { text: "Perintah ini khusus admin grup." }, { quoted: msg });
    return;
  }

  const botCanAdmin = await isBotAdmin(sock, from);

  if (["kick", "promote", "demote"].includes(command)) {
    const target = mentionedInMsg[0] || (quoted?.key?.participant);
    if (!target) {
      await sock.sendMessage(from, { text: `Tag/reply user yang mau di-${command}.` }, { quoted: msg });
      return;
    }
    if (!botCanAdmin) {
      await sock.sendMessage(from, { text: "Bot harus jadi admin dulu untuk melakukan ini." }, { quoted: msg });
      return;
    }
    const action = command === "kick" ? "remove" : command === "promote" ? "promote" : "demote";
    await sock.groupParticipantsUpdate(from, [target], action);
    await sock.sendMessage(from, {
      text: `✅ Berhasil ${command} @${target.split("@")[0]}`,
      mentions: [target],
    });
    return;
  }

  if (command === "add") {
    if (!fullArgs) {
      await sock.sendMessage(from, { text: `Contoh: ${pfx}add 628123456789` }, { quoted: msg });
      return;
    }
    if (!botCanAdmin) {
      await sock.sendMessage(from, { text: "Bot harus jadi admin dulu untuk menambah member." }, { quoted: msg });
      return;
    }
    const number = fullArgs.replace(/\D/g, "") + "@s.whatsapp.net";
    await sock.groupParticipantsUpdate(from, [number], "add");
    await sock.sendMessage(from, { text: `✅ Berhasil menambahkan ${fullArgs}` });
    return;
  }

  if (command === "welcome") {
    const status = fullArgs.toLowerCase();
    if (!["on", "off"].includes(status)) {
      await sock.sendMessage(from, { text: `Contoh: ${pfx}welcome on / ${pfx}welcome off` }, { quoted: msg });
      return;
    }
    db.setWelcome(from, status === "on");
    await sock.sendMessage(from, { text: `✅ Welcome & leave message di-set: ${status}` });
    return;
  }

  if (command === "antilink") {
    const status = fullArgs.toLowerCase();
    if (!["on", "off"].includes(status)) {
      await sock.sendMessage(from, { text: `Contoh: ${pfx}antilink on / ${pfx}antilink off` }, { quoted: msg });
      return;
    }
    db.setAntilink(from, status === "on");
    await sock.sendMessage(from, { text: `✅ Antilink di-set: ${status}` });
    return;
  }

  if (command === "resetwarn") {
    const target = mentionedInMsg[0] || quoted?.key?.participant;
    if (!target) {
      await sock.sendMessage(from, { text: `Tag/reply user yang mau di-reset warning-nya.` }, { quoted: msg });
      return;
    }
    db.resetWarn(from, target);
    await sock.sendMessage(from, {
      text: `✅ Warning @${target.split("@")[0]} sudah direset.`,
      mentions: [target],
    });
    return;
  }
}

module.exports = { handleMessage, isBotAdmin, isSenderAdmin, isOwner, formatDuration };
