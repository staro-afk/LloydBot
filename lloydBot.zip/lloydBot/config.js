module.exports = {
  prefix: ".",
  ownerNumber: "-",
  phoneNumber: "-",
  ownerLid: "-",
  botName: "Lloyd",
  stickerPack: "WA-BOT",
  stickerAuthor: "LloydBot",
  maxWarn: 3,
  geminiApiKey: "-",
  removeBgApiKey: "-",
};
