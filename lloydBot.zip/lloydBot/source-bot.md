

# FILE: ./index.js

```js
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  jidNormalizedUser,
} = require("@whiskeysockets/baileys");
const { Boom } = require("@hapi/boom");
const pino = require("pino");
const readline = require("readline");

const config = require("./config");
const db = require("./lib/database");
const { handleMessage, isBotAdmin, isOwner } = require("./handler");

const spamTracker = new Map();
const SPAM_WINDOW_MS = 7000;
const SPAM_MAX_MSG = 5;

async function checkAntispam(sock, groupId, sender, msg) {
  const key = `${groupId}:${sender}`;
  const now = Date.now();
  const arr = (spamTracker.get(key) || []).filter((t) => now - t < SPAM_WINDOW_MS);
  arr.push(now);
  spamTracker.set(key, arr);

  if (arr.length > SPAM_MAX_MSG) {
    spamTracker.set(key, []);
    const warnCount = db.addWarn(groupId, sender);
    if (warnCount >= config.maxWarn) {
      const botCanAdmin = await isBotAdmin(sock, groupId);
      if (botCanAdmin) {
        await sock.sendMessage(groupId, {
          text: `🚫 @${sender.split("@")[0]} dikeluarkan karena spam (melebihi ${config.maxWarn}x peringatan).`,
          mentions: [sender],
        });
        await sock.groupParticipantsUpdate(groupId, [sender], "remove");
        db.resetWarn(groupId, sender);
        return;
      }
    }
    await sock.sendMessage(groupId, {
      text: `⚠️ @${sender.split("@")[0]} terdeteksi spam! Peringatan ${warnCount}/${config.maxWarn}.`,
      mentions: [sender],
    });
  }
}

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise((resolve) => rl.question(text, resolve));
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState("./session");
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    auth: state,
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
    browser: ["Ubuntu", "Chrome", "20.0.04"],
  });

  if (!sock.authState.creds.registered) {
    let phoneNumber = config.phoneNumber;
    if (!phoneNumber) {
      phoneNumber = await question(
        "Masukkan nomor WhatsApp bot (format: 628123456789, tanpa + / spasi): "
      );
    }
    phoneNumber = phoneNumber.replace(/[^0-9]/g, "");

    setTimeout(async () => {
      try {
        const code = await sock.requestPairingCode(phoneNumber);
        console.log("========================================");
        console.log(`Kode Pairing kamu: ${code}`);
        console.log("Buka WhatsApp > Perangkat Tertaut > Tautkan dengan nomor telepon,");
        console.log("lalu masukkan kode di atas.");
        console.log("========================================");
      } catch (e) {
        console.error("Gagal minta pairing code:", e);
      }
    }, 3000);
  }

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const shouldReconnect =
        new Boom(lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut;
      console.log("Koneksi terputus, reconnect:", shouldReconnect);
      if (shouldReconnect) startBot();
    } else if (connection === "open") {
      console.log(`✅ ${config.botName} berhasil terhubung ke WhatsApp!`);
    }
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    const msg = messages[0];
    if (!msg?.message || msg.key.fromMe) return;

    const from = msg.key.remoteJid;
    const isGroup = from.endsWith("@g.us");
    const sender = isGroup ? msg.key.participant : from;
    const text =
      msg.message.conversation ||
      msg.message.extendedTextMessage?.text ||
      "";

    if (isGroup && sender && !text.startsWith(config.prefix)) {
      checkAntispam(sock, from, sender, msg).catch(console.error);
    }

    handleMessage(sock, msg).catch(console.error);
  });

  sock.ev.on("group-participants.update", async (event) => {
    const { id: groupId, participants, action, author } = event;

    // ==== Anti auto-add: bot ditambahin tanpa izin owner -> keluar ====
    if (action === "add") {
      const botJidNorm = jidNormalizedUser(sock.user.id);
      const botAdded = participants.some((p) => jidNormalizedUser(p) === botJidNorm);
      if (botAdded) {
        let allowedByOwner = false;
        if (author) {
          allowedByOwner = await isOwner(sock, true, groupId, author);
        } else {
          try {
            const metadata = await sock.groupMetadata(groupId);
            for (const p of metadata.participants) {
              if (await isOwner(sock, true, groupId, p.id)) {
                allowedByOwner = true;
                break;
              }
            }
          } catch (e) {}
        }
        if (!allowedByOwner) {
          console.log(`Ditambahkan ke grup ${groupId} tanpa izin owner, keluar...`);
          await sleep(1000 + Math.random() * 500);
          try {
            await sock.sendMessage(groupId, { text:"🚫 Bot cuma boleh ditambahkan oleh owner. Bye!" });
          } catch (e) {}
          await sleep(1000 + Math.random() * 500);
          await sock.groupLeave(groupId);
          return;
        }
      }
    }

    // ==== Anti-kudeta: owner di-kick/keluar -> bot ikut keluar ====
    if (action === "remove") {
      for (const p of participants) {
        const ownerRemoved = await isOwner(sock, true, groupId, p);
        if (ownerRemoved) {
          console.log(`Owner keluar/di-kick dari grup ${groupId}, bot ikut keluar...`);
          await sleep(1000 + Math.random() * 500);
          try {
            await sock.sendMessage(groupId, { text: "👋 Owner udah nggak ada di grup ini, bot pamit juga." });
          }catch (e) {}
          await sleep(1000 + Math.random() * 500);
          await sock.groupLeave(groupId);
          return;
        }
      }
    }

    if (!db.isWelcomeActive(groupId)) return;

    try {
      const metadata = await sock.groupMetadata(groupId);
      for (const participant of participants) {
        if (action === "add") {
          await sock.sendMessage(groupId, {
            text: `👋 Selamat datang @${participant.split("@")[0]} di grup *${metadata.subject}*!\nBaca deskripsi grup & jangan lupa cek ${config.prefix}menu ya.`,
            mentions: [participant],
          });
        } else if (action === "remove") {
          await sock.sendMessage(groupId, {
            text: `👋 @${participant.split("@")[0]} telah meninggalkan grup.`,
            mentions: [participant],
          });
        }
      }
    } catch (e) {
      if (e?.data !== 404 && e?.output?.statusCode !== 404) {
        console.error("Welcome/leave error:", e.message || e);
      }
    }
  });

  // ==== Anti auto-add versi 2: nangkep grup yang BARU dibuat & bot ====
  // ==== langsung dimasukin pas pembuatan (event beda dari update biasa) ====
  sock.ev.on("groups.upsert", async (groups) => {
    for (const g of groups) {
      try {
        let allowed = false;

        if (g.owner) {
          allowed = await isOwner(sock, true, g.id, g.owner);
        }

        if (!allowed) {
          let participants = g.participants;
          if (!participants) {
            const metadata = await sock.groupMetadata(g.id);
            participants = metadata.participants;
          }
          for (const p of participants) {
            if (await isOwner(sock, true, g.id, p.id)) {
              allowed = true;
              break;
            }
          }
        }

        if (!allowed) {
          console.log(`Grup baru ${g.id} dibuat tanpa owner, bot keluar...`);
          await sleep(1000 + Math.random() * 500);
          try {
            await sock.sendMessage(g.id, { text: "🚫 Bot cuma boleh ditambahkan oleh owner. Bye!" });
          } catch (e) {}
          await sleep(1000 + Math.random() * 500);
          await sock.groupLeave(g.id);
        }
      } catch (e) {
        console.error("groups.upsert anti-add error:", e);
      }
    }
  });

  return sock;
}

startBot().catch((err) => console.error("Gagal start bot:", err));

```


# FILE: ./lib/sticker.js

```js
const fs = require("fs");
const os = require("os");
const path = require("path");
const { execFile } = require("child_process");

function run(cmd, args) {
  return new Promise((resolve, reject) => {
    execFile(cmd, args, { maxBuffer: 1024 * 1024 * 50 }, (err, stdout, stderr) => {
      if (err) return reject(new Error(stderr || err.message));
      resolve(stdout);
    });
  });
}

async function bufferToSticker(buffer, isVideo = false) {
  const tmpDir = os.tmpdir();
  const id = Date.now() + "-" + Math.random().toString(36).slice(2);
  const inputExt = isVideo ? "mp4" : "png";
  const inputPath = path.join(tmpDir, `in-${id}.${inputExt}`);
  const outputPath = path.join(tmpDir, `out-${id}.webp`);

  fs.writeFileSync(inputPath, buffer);

  try {
    if (isVideo) {
      await run("ffmpeg", [
        "-y", "-i", inputPath,
        "-vcodec", "libwebp",
        "-vf", "scale=512:512:force_original_aspect_ratio=decrease,fps=15",
        "-loop", "0",
        "-preset", "default",
        "-an", "-vsync", "0",
        "-t", "6",
        outputPath,
      ]);
    } else {
      await run("ffmpeg", [
        "-y", "-i", inputPath,
        "-vf",
        "scale=512:512:force_original_aspect_ratio=decrease,format=rgba,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000",
        outputPath,
      ]);
    }
    return fs.readFileSync(outputPath);
  } finally {
    if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
    if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
  }
}

module.exports = { bufferToSticker };

```


# FILE: ./lib/brat.js

```js
const Jimp = require("jimp");
const axios = require("axios");

const emojiCache = new Map();

function isEmoji(grapheme) {
  return /\p{Extended_Pictographic}/u.test(grapheme);
}

function toCodepoints(grapheme, stripVariationSelector) {
  return Array.from(grapheme)
    .map((c) => c.codePointAt(0))
    .filter((cp) => !(stripVariationSelector && cp === 0xfe0f))
    .map((cp) => cp.toString(16))
    .join("-");
}

async function fetchEmojiImage(grapheme) {
  const cacheKey = grapheme;
  if (emojiCache.has(cacheKey)) return emojiCache.get(cacheKey);

  const attempts = [toCodepoints(grapheme, false), toCodepoints(grapheme, true)];
  for (const cp of attempts) {
    try {
      const url = `https://cdn.jsdelivr.net/gh/jdecked/twemoji@latest/assets/72x72/${cp}.png`;
      const res = await axios.get(url, { responseType: "arraybuffer", timeout: 8000 });
      const buf = Buffer.from(res.data);
      emojiCache.set(cacheKey, buf);
      return buf;
    } catch (e) {
      continue;
    }
  }
  emojiCache.set(cacheKey, null);
  return null;
}

function splitIntoWords(text) {
  const segmenter = new Intl.Segmenter(undefined, { granularity: "grapheme" });
  return text.split(" ").map((word) => {
    const graphemes = Array.from(segmenter.segment(word), (s) => s.segment);
    const plan = [];
    let buffer = "";
    for (const g of graphemes) {
      if (isEmoji(g)) {
        if (buffer) {
          plan.push({ type: "text", value: buffer });
          buffer = "";
        }
        plan.push({ type: "emoji", value: g });
      } else {
        buffer += g;
      }
    }
    if (buffer) plan.push({ type: "text", value: buffer });
    return plan;
  });
}

function measureWord(font, wordPlan, emojiSize) {
  let width = 0;
  for (const seg of wordPlan) {
    if (seg.type === "text") {
      width += Jimp.measureText(font, seg.value);
    } else {
      width += emojiSize;
    }
  }
  return width;
}

function wrapWords(font, words, maxWidth, spaceWidth, emojiSize) {
  const lines = [];
  let currentLine = [];
  let currentWidth = 0;

  for (const word of words) {
    const wordWidth = measureWord(font, word, emojiSize);
    const extra = currentLine.length > 0 ? spaceWidth : 0;
    if (currentWidth + extra + wordWidth > maxWidth && currentLine.length > 0) {
      lines.push(currentLine);
      currentLine = [word];
      currentWidth = wordWidth;
    } else {
      currentLine.push(word);
      currentWidth += extra + wordWidth;
    }
  }
  if (currentLine.length > 0) lines.push(currentLine);
  return lines;
}

const FONT_SIZES = [128, 64, 32, 16];
const FONT_MAP = {
  128: Jimp.FONT_SANS_128_BLACK,
  64: Jimp.FONT_SANS_64_BLACK,
  32: Jimp.FONT_SANS_32_BLACK,
  16: Jimp.FONT_SANS_16_BLACK,
};

async function generateBratImage(text, bgColor = "#FFFFFF") {
  const size = 512;
  const usable = size - 40;
  const content = (text || "brat").toLowerCase();
  const words = splitIntoWords(content);

  let chosenFontSize = FONT_SIZES[FONT_SIZES.length - 1];
  let chosenFont = null;
  let chosenLines = null;
  let chosenEmojiSize = 16;

  for (const fs of FONT_SIZES) {
    const font = await Jimp.loadFont(FONT_MAP[fs]);
    const emojiSize = Math.round(fs * 0.85);
    const spaceWidth = Jimp.measureText(font, " ") || fs * 0.3;
    const lines = wrapWords(font, words, usable, spaceWidth, emojiSize);
    const lineHeight = fs + Math.round(fs * 0.15);
    const totalHeight = lines.length * lineHeight;

    if (totalHeight <= usable || fs === FONT_SIZES[FONT_SIZES.length - 1]) {
      chosenFontSize = fs;
      chosenFont = font;
      chosenLines = lines;
      chosenEmojiSize = emojiSize;
      break;
    }
  }

  const image = new Jimp(size, size, bgColor);
  const spaceWidth = Jimp.measureText(chosenFont, " ") || chosenFontSize * 0.3;
  const lineHeight = chosenFontSize + Math.round(chosenFontSize * 0.15);
  const totalHeight = chosenLines.length * lineHeight;
  let startY = Math.max(20, (size - totalHeight) / 2);

  const emojiBuffers = {};
  for (const line of chosenLines) {
    for (const word of line) {
      for (const seg of word) {
        if (seg.type === "emoji" && !(seg.value in emojiBuffers)) {
          emojiBuffers[seg.value] = await fetchEmojiImage(seg.value);
        }
      }
    }
  }

  for (const line of chosenLines) {
    const lineWidth =
      line.reduce((sum, w) => sum + measureWord(chosenFont, w, chosenEmojiSize), 0) +
      spaceWidth * Math.max(0, line.length - 1);
    let x = Math.max(20, (size - lineWidth) / 2);
    const y = startY;

    for (let wi = 0; wi < line.length; wi++) {
      const word = line[wi];
      for (const seg of word) {
        if (seg.type === "text") {
          image.print(chosenFont, x, y, seg.value);
          x += Jimp.measureText(chosenFont, seg.value);
        } else {
          const buf = emojiBuffers[seg.value];
          if (buf) {
            try {
              const emojiImg = await Jimp.read(buf);
              emojiImg.resize(chosenEmojiSize, chosenEmojiSize);
              const yOffset = Math.round((chosenFontSize - chosenEmojiSize) / 2) + 4;
              image.composite(emojiImg, Math.round(x), Math.round(y + yOffset));
            } catch (e) {}
          }
          x += chosenEmojiSize;
        }
      }
      if (wi < line.length - 1) x += spaceWidth;
    }

    startY += lineHeight;
  }

  return image.getBufferAsync(Jimp.MIME_PNG);
}

module.exports = { generateBratImage };

```


# FILE: ./lib/database.js

```js
const fs = require("fs-extra");
const path = require("path");

const DATA_DIR = path.join(__dirname, "..", "data");
fs.ensureDirSync(DATA_DIR);

function filePath(name) {
  return path.join(DATA_DIR, `${name}.json`);
}

function load(name, fallback = {}) {
  const p = filePath(name);
  if (!fs.existsSync(p)) {
    fs.writeJsonSync(p, fallback, { spaces: 2 });
    return fallback;
  }
  try {
    return fs.readJsonSync(p);
  } catch (e) {
    return fallback;
  }
}

function save(name, data) {
  fs.writeJsonSync(filePath(name), data, { spaces: 2 });
}

function setAfk(jid, reason) {
  const db = load("afk");
  db[jid] = { reason: reason || "Tidak ada alasan", time: Date.now() };
  save("afk", db);
}
function getAfk(jid) {
  const db = load("afk");
  return db[jid];
}
function removeAfk(jid) {
  const db = load("afk");
  if (db[jid]) {
    delete db[jid];
    save("afk", db);
    return true;
  }
  return false;
}

function setAntilink(groupId, status) {
  const db = load("antilink");
  db[groupId] = status;
  save("antilink", db);
}
function isAntilinkActive(groupId) {
  const db = load("antilink");
  return !!db[groupId];
}

function setWelcome(groupId, status) {
  const db = load("welcome");
  db[groupId] = status;
  save("welcome", db);
}
function isWelcomeActive(groupId) {
  const db = load("welcome");
  return db[groupId] === undefined ? true : db[groupId];
}

function addWarn(groupId, userId) {
  const db = load("warn");
  if (!db[groupId]) db[groupId] = {};
  db[groupId][userId] = (db[groupId][userId] || 0) + 1;
  save("warn", db);
  return db[groupId][userId];
}
function getWarn(groupId, userId) {
  const db = load("warn");
  return (db[groupId] && db[groupId][userId]) || 0;
}
function resetWarn(groupId, userId) {
  const db = load("warn");
  if (db[groupId]) {
    delete db[groupId][userId];
    save("warn", db);
  }
}

function setMode(mode) {
  save("settings", { mode });
}
function getMode() {
  const db = load("settings", { mode: "public" });
  return db.mode || "public";
}

function addSultan(jid) {
  const db = load("sultan", { jids: [] });
  if (!db.jids.includes(jid)) {
    db.jids.push(jid);
    save("sultan", db);
  }
}
function removeSultan(jid) {
  const db = load("sultan", { jids: [] });
  db.jids = db.jids.filter((j) => j !== jid);
  save("sultan", db);
}
function isSultan(jid) {
  const db = load("sultan", { jids: [] });
  return db.jids.includes(jid);
}
function getSultanList() {
  const db = load("sultan", { jids: [] });
  return db.jids;
}

module.exports = {
  setAfk,
  getAfk,
  removeAfk,
  setAntilink,
  isAntilinkActive,
  setWelcome,
  isWelcomeActive,
  addWarn,
  getWarn,
  resetWarn,
  setMode,
  getMode,
  addSultan,
  removeSultan,
  isSultan,
  getSultanList,
};

```


# FILE: ./lib/downloader.js

```js
const fs = require("fs");
const os = require("os");
const path = require("path");
const { execFile } = require("child_process");
const axios = require("axios");
const Jimp = require("jimp");

function runYtDlp(args) {
  return new Promise((resolve, reject) => {
    execFile("yt-dlp", args, { maxBuffer: 1024 * 1024 * 200 }, (err, stdout, stderr) => {
      if (err) return reject(new Error(stderr || err.message));
      resolve(stdout);
    });
  });
}

async function searchYoutube(query) {
  const out = await runYtDlp([
    "--dump-json",
    "--skip-download",
    "--no-warnings",
    `ytsearch1:${query}`,
  ]);
  const line = out.trim().split("\n")[0];
  if (!line) return null;
  const info = JSON.parse(line);
  return {
    title: info.title,
    url: info.webpage_url || `https://www.youtube.com/watch?v=${info.id}`,
  };
}

async function downloadYoutubeAudio(url) {
  const tmpDir = os.tmpdir();
  const id = Date.now() + "-" + Math.random().toString(36).slice(2);
  const outputTemplate = path.join(tmpDir, `audio-${id}.%(ext)s`);

  await runYtDlp([
    "-x",
    "--audio-format", "mp3",
    "--audio-quality", "6",
    "--concurrent-fragments", "4",
    "--extractor-args", "youtube:player_client=android",
    "--no-playlist",
    "--match-filter", "duration <= 600",
    "--no-warnings",
    "-o", outputTemplate,
    url,
  ]);

  const finalPath = path.join(tmpDir, `audio-${id}.mp3`);
  const buffer = fs.readFileSync(finalPath);
  fs.unlinkSync(finalPath);
  return buffer;
}

async function downloadYoutubeVideo(url) {
  const tmpDir = os.tmpdir();
  const id = Date.now() + "-" + Math.random().toString(36).slice(2);
  const outputPath = path.join(tmpDir, `video-${id}.mp4`);

  await runYtDlp([
    "-f", "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b",
    "--merge-output-format", "mp4",
    "--no-playlist",
    "--no-warnings",
    "-o", outputPath,
    url,
  ]);

  const buffer = fs.readFileSync(outputPath);
  fs.unlinkSync(outputPath);
  return buffer;
}

async function tiktokNoWatermark(url) {
  const { data } = await axios.get("https://www.tikwm.com/api/", {
    params: { url },
    timeout: 20000,
  });
  if (!data || data.code !== 0 || !data.data) {
    throw new Error("Gagal ambil data TikTok, cek lagi link-nya.");
  }
  const d = data.data;
  return {
    videoUrl: d.play,
    title: d.title,
    author: d.author?.nickname || "unknown",
  };
}

async function generateQuotly({ text, name }) {
  const width = 512;
  const padding = 40;
  const content = text || "...";
  const displayName = name || "User";

  const fontBody = content.length > 60
    ? await Jimp.loadFont(Jimp.FONT_SANS_16_WHITE)
    : await Jimp.loadFont(Jimp.FONT_SANS_32_WHITE);
  const fontName = await Jimp.loadFont(Jimp.FONT_SANS_16_WHITE);

  const textHeight = Jimp.measureTextHeight(fontBody, content, width - padding * 2);
  const totalHeight = textHeight + 100;

  const image = new Jimp(width, totalHeight, "#1b1429");

  image.print(
    fontBody,
    padding,
    30,
    { text: content, alignmentX: Jimp.HORIZONTAL_ALIGN_LEFT },
    width - padding * 2,
    textHeight
  );

  image.print(
    fontName,
    padding,
    totalHeight - 45,
    { text: `~ ${displayName}`, alignmentX: Jimp.HORIZONTAL_ALIGN_LEFT },
    width - padding * 2
  );

  return image.getBufferAsync(Jimp.MIME_PNG);
}

module.exports = {
  searchYoutube,
  downloadYoutubeAudio,
  downloadYoutubeVideo,
  tiktokNoWatermark,
  generateQuotly,
};

```


# FILE: ./lib/fakecall.js

```js
const Jimp = require("jimp");

function drawCircle(image, cx, cy, radius, colorInt) {
  for (let y = cy - radius; y <= cy + radius; y++) {
    for (let x = cx - radius; x <= cx + radius; x++) {
      if (x < 0 || y < 0 || x >= image.bitmap.width || y >= image.bitmap.height) continue;
      const dx = x - cx;
      const dy = y - cy;
      if (dx * dx + dy * dy <= radius * radius) {
        image.setPixelColor(colorInt, x, y);
      }
    }
  }
}

function drawRect(image, x, y, w, h, colorInt) {
  for (let yy = y; yy < y + h; yy++) {
    for (let xx = x; xx < x + w; xx++) {
      if (xx < 0 || yy < 0 || xx >= image.bitmap.width || yy >= image.bitmap.height) continue;
      image.setPixelColor(colorInt, xx, yy);
    }
  }
}

function drawTriangleRight(image, x, y, size, colorInt) {
  for (let dx = 0; dx <= size; dx++) {
    const half = Math.round((size - dx) / 2);
    for (let dy = -half; dy <= half; dy++) {
      const px = x + dx;
      const py = y + dy;
      if (px < 0 || py < 0 || px >= image.bitmap.width || py >= image.bitmap.height) continue;
      image.setPixelColor(colorInt, px, py);
    }
  }
}

function drawTriangleUp(image, cx, cy, size, colorInt) {
  for (let dy = 0; dy <= size; dy++) {
    const half = Math.round((dy / size) * size * 0.6);
    for (let dx = -half; dx <= half; dx++) {
      const px = cx + dx;
      const py = cy - size + dy;
      if (px < 0 || py < 0 || px >= image.bitmap.width || py >= image.bitmap.height) continue;
      image.setPixelColor(colorInt, px, py);
    }
  }
}

function drawThickLine(image, x1, y1, x2, y2, thickness, colorInt) {
  const steps = Math.max(Math.abs(x2 - x1), Math.abs(y2 - y1), 1);
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const x = Math.round(x1 + (x2 - x1) * t);
    const y = Math.round(y1 + (y2 - y1) * t);
    drawCircle(image, x, y, thickness / 2, colorInt);
  }
}

function iconSpeaker(image, cx, cy, colorInt) {
  drawRect(image, cx - 20, cy - 8, 10, 16, colorInt);
  drawTriangleRight(image, cx - 10, cy, 16, colorInt);
}

function iconVideo(image, cx, cy, colorInt) {
  drawRect(image, cx - 18, cy - 10, 24, 20, colorInt);
  drawTriangleRight(image, cx + 6, cy, 14, colorInt);
}

function iconMic(image, cx, cy, colorInt, muted) {
  drawRect(image, cx - 7, cy - 16, 14, 22, colorInt);
  drawCircle(image, cx, cy - 16, 7, colorInt);
  drawThickLine(image, cx, cy + 8, cx, cy + 16, 4, colorInt);
  drawThickLine(image, cx - 10, cy + 16, cx + 10, cy + 16, 4, colorInt);
  if (muted) {
    drawThickLine(image, cx - 20, cy - 22, cx + 20, cy + 22, 6, Jimp.cssColorToHex("#f15c6d"));
  }
}

function iconMore(image, cx, cy, colorInt) {
  drawCircle(image, cx - 16, cy, 5, colorInt);
  drawCircle(image, cx, cy, 5, colorInt);
  drawCircle(image, cx + 16, cy, 5, colorInt);
}

function iconShare(image, cx, cy, colorInt) {
  drawTriangleUp(image, cx, cy - 4, 16, colorInt);
  drawThickLine(image, cx, cy + 2, cx, cy + 18, 6, colorInt);
}

function iconEndCall(image, cx, cy, colorInt) {
  drawThickLine(image, cx - 16, cy - 16, cx + 16, cy + 16, 12, colorInt);
  drawCircle(image, cx - 16, cy - 16, 10, colorInt);
  drawCircle(image, cx + 16, cy + 16, 10, colorInt);
}

async function generateFakeCallImage({ name, duration, avatarBuffer }) {
  const width = 512;
  const height = 1000;
  const displayName = (name || "Unknown").trim() || "Unknown";
  const displayDuration = duration || "00:00";

  const bg = new Jimp(width, height, "#0b141a");

  if (avatarBuffer) {
    try {
      const bgPhoto = await Jimp.read(avatarBuffer);
      bgPhoto.cover(width, height).blur(14).brightness(-0.5);
      bg.composite(bgPhoto, 0, 0);
    } catch (e) {}
  } else {
    bg.scan(0, 0, width, height, function (x, y, idx) {
      const ratio = y / height;
      const r = Math.round(5 + ratio * 15);
      const g = Math.round(15 + ratio * 25);
      const b = Math.round(20 + ratio * 25);
      this.bitmap.data[idx] = r;
      this.bitmap.data[idx + 1] = g;
      this.bitmap.data[idx + 2] = b;
      this.bitmap.data[idx + 3] = 255;
    });
  }

  const fontName = await Jimp.loadFont(Jimp.FONT_SANS_32_WHITE);
  const nameWidth = Jimp.measureText(fontName, displayName);
  bg.print(fontName, Math.max(20, width / 2 - nameWidth / 2), 150, displayName);

  const fontTimer = await Jimp.loadFont(Jimp.FONT_SANS_16_WHITE);
  const timerWidth = Jimp.measureText(fontTimer, displayDuration);
  bg.print(fontTimer, width / 2 - timerWidth / 2, 200, displayDuration);

  const avatarRadius = 160;
  const avatarCx = width / 2;
  const avatarCy = 430;

  if (avatarBuffer) {
    try {
      const avatar = await Jimp.read(avatarBuffer);
      avatar.cover(avatarRadius * 2, avatarRadius * 2).circle();
      bg.composite(avatar, avatarCx - avatarRadius, avatarCy - avatarRadius);
    } catch (e) {
      drawCircle(bg, avatarCx, avatarCy, avatarRadius, Jimp.cssColorToHex("#2a3942"));
      const fontBig = await Jimp.loadFont(Jimp.FONT_SANS_64_WHITE);
      const initial = displayName.charAt(0).toUpperCase();
      const iw = Jimp.measureText(fontBig, initial);
      bg.print(fontBig, avatarCx - iw / 2, avatarCy - 45, initial);
    }
  } else {
    drawCircle(bg, avatarCx, avatarCy, avatarRadius, Jimp.cssColorToHex("#2a3942"));
    const fontBig = await Jimp.loadFont(Jimp.FONT_SANS_64_WHITE);
    const initial = displayName.charAt(0).toUpperCase();
    const iw = Jimp.measureText(fontBig, initial);
    bg.print(fontBig, avatarCx - iw / 2, avatarCy - 45, initial);
  }

  const panelWidth = 430;
  const panelHeight = 280;
  const panelX = (width - panelWidth) / 2;
  const panelY = 680;

  const panel = new Jimp(panelWidth, panelHeight, Jimp.rgbaToInt(31, 44, 52, 210));
  bg.composite(panel, panelX, panelY);

  const iconRadius = 38;
  const colX = [panelX + panelWidth * (1 / 6), panelX + panelWidth * 0.5, panelX + panelWidth * (5 / 6)];
  const row1Y = panelY + 70;
  const row2Y = panelY + 190;

  const fontLabel = await Jimp.loadFont(Jimp.FONT_SANS_16_WHITE);
  const white = Jimp.cssColorToHex("#ffffff");
  const circleBg = Jimp.rgbaToInt(255, 255, 255, 55);

  drawCircle(bg, colX[0], row1Y, iconRadius, circleBg);
  iconSpeaker(bg, colX[0], row1Y, white);
  let lw = Jimp.measureText(fontLabel, "Speaker");
  bg.print(fontLabel, colX[0] - lw / 2, row1Y + iconRadius + 12, "Speaker");

  drawCircle(bg, colX[1], row1Y, iconRadius, circleBg);
  iconVideo(bg, colX[1], row1Y, white);
  lw = Jimp.measureText(fontLabel, "Video");
  bg.print(fontLabel, colX[1] - lw / 2, row1Y + iconRadius + 12, "Video");

  drawCircle(bg, colX[2], row1Y, iconRadius, circleBg);
  iconMic(bg, colX[2], row1Y, white, true);
  lw = Jimp.measureText(fontLabel, "Bisukan");
  bg.print(fontLabel, colX[2] - lw / 2, row1Y + iconRadius + 12, "Bisukan");

  drawCircle(bg, colX[0], row2Y, iconRadius, circleBg);
  iconMore(bg, colX[0], row2Y, white);
  lw = Jimp.measureText(fontLabel, "Lainnya");
  bg.print(fontLabel, colX[0] - lw / 2, row2Y + iconRadius + 12, "Lainnya");

  drawCircle(bg, colX[1], row2Y, iconRadius, circleBg);
  iconShare(bg, colX[1], row2Y, white);
  lw = Jimp.measureText(fontLabel, "Bagikan");
  bg.print(fontLabel, colX[1] - lw / 2, row2Y + iconRadius + 12, "Bagikan");

  const red = Jimp.cssColorToHex("#f15c6d");
  drawCircle(bg, colX[2], row2Y, iconRadius, red);
  iconEndCall(bg, colX[2], row2Y, white);
  lw = Jimp.measureText(fontLabel, "Akhiri");
  bg.print(fontLabel, colX[2] - lw / 2, row2Y + iconRadius + 12, "Akhiri");

  return bg.getBufferAsync(Jimp.MIME_PNG);
}

module.exports = { generateFakeCallImage };

```


# FILE: ./lib/economy.js

```js
const fs = require("fs-extra");
const path = require("path");

const DATA_DIR = path.join(__dirname, "..", "data");
fs.ensureDirSync(DATA_DIR);
const FILE = path.join(DATA_DIR, "economy.json");

function loadAll() {
  if (!fs.existsSync(FILE)) {
    fs.writeJsonSync(FILE, {}, { spaces: 2 });
    return {};
  }
  try {
    return fs.readJsonSync(FILE);
  } catch (e) {
    return {};
  }
}

function saveAll(data) {
  fs.writeJsonSync(FILE, data, { spaces: 2 });
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

const DEFAULT_TOKEN = 20;

function getUser(jid) {
  const all = loadAll();
  if (!all[jid]) {
    all[jid] = { level: 1, money: 0, token: DEFAULT_TOKEN, lastReset: todayStr() };
    saveAll(all);
    return all[jid];
  }
  if (all[jid].lastReset !== todayStr()) {
    all[jid].token = Math.max(all[jid].token || 0, DEFAULT_TOKEN);
    all[jid].lastReset = todayStr();
    saveAll(all);
  }
  return all[jid];
}

function updateUser(jid, patch) {
  const all = loadAll();
  const current = all[jid] || { level: 1, money: 0, token: DEFAULT_TOKEN, lastReset: todayStr() };
  all[jid] = { ...current, ...patch };
  saveAll(all);
  return all[jid];
}

function getLeaderboard(limit) {
  const all = loadAll();
  const list = Object.entries(all).map(([jid, data]) => ({ jid, ...data }));
  list.sort((a, b) => (b.money || 0) - (a.money || 0));
  return list.slice(0, limit || 10);
}

function getRank(jid) {
  const all = loadAll();
  const list = Object.entries(all).map(([j, data]) => ({ jid: j, ...data }));
  list.sort((a, b) => (b.money || 0) - (a.money || 0));
  const index = list.findIndex((u) => u.jid === jid);
  return { rank: index === -1 ? null : index + 1, total: list.length };
}

module.exports = { getUser, updateUser, DEFAULT_TOKEN, getLeaderboard, getRank };


```


# FILE: ./lib/ulartangga.js

```js
const Jimp = require("jimp");
const fs = require("fs-extra");
const path = require("path");

const DATA_DIR = path.join(__dirname, "..", "data");
fs.ensureDirSync(DATA_DIR);
const FILE = path.join(DATA_DIR, "ulartangga.json");

function loadAll() {
  if (!fs.existsSync(FILE)) {
    fs.writeJsonSync(FILE, {}, { spaces: 2 });
    return {};
  }
  try {
    return fs.readJsonSync(FILE);
  } catch (e) {
    return {};
  }
}
function saveAll(data) {
  fs.writeJsonSync(FILE, data, { spaces: 2 });
}

const SNAKES_LADDERS = {
  1: 38, 4: 14, 9: 31, 21: 42, 28: 84, 36: 44, 51: 67, 71: 91, 80: 100,
  16: 6, 47: 26, 49: 11, 56: 53, 62: 19, 64: 60, 87: 24, 93: 73, 95: 75, 98: 78,
};

const TOKEN_COLORS = ["#e74c3c", "#3498db", "#2ecc71", "#f39c12", "#9b59b6", "#1abc9c"];

function drawCircle(image, cx, cy, radius, colorInt) {
  for (let y = cy - radius; y <= cy + radius; y++) {
    for (let x = cx - radius; x <= cx + radius; x++) {
      if (x < 0 || y < 0 || x >= image.bitmap.width || y >= image.bitmap.height) continue;
      const dx = x - cx;
      const dy = y - cy;
      if (dx * dx + dy * dy <= radius * radius) {
        image.setPixelColor(colorInt, x, y);
      }
    }
  }
}

function drawRect(image, x, y, w, h, colorInt) {
  for (let yy = y; yy < y + h; yy++) {
    for (let xx = x; xx < x + w; xx++) {
      if (xx < 0 || yy < 0 || xx >= image.bitmap.width || yy >= image.bitmap.height) continue;
      image.setPixelColor(colorInt, xx, yy);
    }
  }
}

function drawThickLine(image, x1, y1, x2, y2, thickness, colorInt) {
  const steps = Math.max(Math.abs(x2 - x1), Math.abs(y2 - y1), 1);
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const x = Math.round(x1 + (x2 - x1) * t);
    const y = Math.round(y1 + (y2 - y1) * t);
    drawCircle(image, x, y, thickness / 2, colorInt);
  }
}

function drawPawn(image, cx, cy, colorInt) {
  const white = Jimp.cssColorToHex("#ffffff");
  drawCircle(image, cx, cy + 4, 11, white);
  drawCircle(image, cx, cy - 5, 7, white);
  drawCircle(image, cx, cy + 4, 9, colorInt);
  drawCircle(image, cx, cy - 5, 5, colorInt);
}

function drawLadderIcon(image, x, y, colorInt) {
  drawThickLine(image, x, y + 14, x, y, 3, colorInt);
  drawThickLine(image, x + 12, y + 14, x + 12, y, 3, colorInt);
  drawThickLine(image, x, y + 2, x + 12, y + 2, 3, colorInt);
  drawThickLine(image, x, y + 7, x + 12, y + 7, 3, colorInt);
  drawThickLine(image, x, y + 12, x + 12, y + 12, 3, colorInt);
}

function drawSnakeIcon(image, x, y, colorInt) {
  drawCircle(image, x + 6, y + 6, 7, colorInt);
  drawThickLine(image, x + 6, y + 6, x - 4, y + 14, 5, colorInt);
  const white = Jimp.cssColorToHex("#ffffff");
  drawCircle(image, x + 3, y + 3, 1, white);
  drawCircle(image, x + 9, y + 3, 1, white);
}

function pixelForCell(num) {
  const idx = num - 1;
  const row = Math.floor(idx / 10);
  let col = idx % 10;
  if (row % 2 === 1) col = 9 - col;
  const pixelRow = 9 - row;
  return { col, pixelRow };
}

async function generateBoardImage(players) {
  const cellSize = 50;
  const margin = 20;
  const boardPx = cellSize * 10;
  const size = boardPx + margin * 2;

  const image = new Jimp(size, size, "#f5f0e6");
  const fontNum = await Jimp.loadFont(Jimp.FONT_SANS_16_BLACK);
  const fontSmall = await Jimp.loadFont(Jimp.FONT_SANS_16_WHITE);

  for (let num = 1; num <= 100; num++) {
    const { col, pixelRow } = pixelForCell(num);
    const x = margin + col * cellSize;
    const y = margin + pixelRow * cellSize;

    const isLight = (col + pixelRow) % 2 === 0;
    let cellColor = isLight ? "#fdf6e3" : "#eee8d5";

    const dest = SNAKES_LADDERS[num];
    let isLadder = false;
    let isSnake = false;
    if (dest !== undefined) {
      if (dest > num) {
        cellColor = "#a8e6a3";
        isLadder = true;
      } else {
        cellColor = "#f3a6a6";
        isSnake = true;
      }
    }

    drawRect(image, x, y, cellSize, cellSize, Jimp.cssColorToHex(cellColor));

    for (let i = 0; i < cellSize; i++) {
      image.setPixelColor(Jimp.cssColorToHex("#c9c2ad"), x + i, y);
      image.setPixelColor(Jimp.cssColorToHex("#c9c2ad"), x, y + i);
    }

    image.print(fontNum, x + 3, y + 2, String(num));

    if (isLadder) {
      drawLadderIcon(image, x + cellSize - 18, y + 2, Jimp.cssColorToHex("#2e7d32"));
      image.print(fontSmall, x + 3, y + 30, "^" + dest);
    } else if (isSnake) {
      drawSnakeIcon(image, x + cellSize - 20, y + 2, Jimp.cssColorToHex("#c0392b"));
      image.print(fontSmall, x + 3, y + 30, "v" + dest);
    }
  }

  players.forEach((p, i) => {
    const pos = Math.max(1, Math.min(100, p.position || 1));
    const { col, pixelRow } = pixelForCell(pos);
    const baseX = margin + col * cellSize + cellSize / 2;
    const baseY = margin + pixelRow * cellSize + cellSize / 2;
    const offsets = [
      [-12, -8], [12, -8], [-12, 10], [12, 10], [0, -14], [0, 12],
    ];
    const [ox, oy] = offsets[i % offsets.length];
    const color = Jimp.cssColorToHex(TOKEN_COLORS[i % TOKEN_COLORS.length]);
    drawPawn(image, baseX + ox, baseY + oy, color);
  });

  return image.getBufferAsync(Jimp.MIME_PNG);
}

function getGame(groupId) {
  const all = loadAll();
  return all[groupId] || null;
}

function createGame(groupId, mode, starterJid, starterName) {
  const all = loadAll();
  all[groupId] = {
    mode,
    status: mode === "solo" ? "playing" : "waiting",
    players: [{ jid: starterJid, name: starterName, position: 1 }],
    turnIndex: 0,
    startedBy: starterJid,
  };
  saveAll(all);
  return all[groupId];
}

function joinGame(groupId, jid, name) {
  const all = loadAll();
  const game = all[groupId];
  if (!game || game.status !== "waiting") return null;
  if (game.players.some((p) => p.jid === jid)) return game;
  game.players.push({ jid, name, position: 1 });
  saveAll(all);
  return game;
}

function beginGame(groupId) {
  const all = loadAll();
  const game = all[groupId];
  if (!game || game.status !== "waiting") return null;
  game.status = "playing";
  saveAll(all);
  return game;
}

function cancelGame(groupId) {
  const all = loadAll();
  if (!all[groupId]) return false;
  delete all[groupId];
  saveAll(all);
  return true;
}

function rollDice(groupId, jid) {
  const all = loadAll();
  const game = all[groupId];
  if (!game || game.status !== "playing") {
    return { error: "Nggak ada game yang lagi jalan di grup ini." };
  }

  const playerIndex = game.players.findIndex((p) => p.jid === jid);
  if (playerIndex === -1) {
    return { error: "Kamu bukan pemain di game ini." };
  }

  if (game.mode === "multi" && playerIndex !== game.turnIndex) {
    const current = game.players[game.turnIndex];
    return { error: `Bukan giliran kamu. Sekarang giliran ${current.name}.` };
  }

  const player = game.players[playerIndex];
  const roll = Math.floor(Math.random() * 6) + 1;
  const oldPos = player.position;
  let newPos = oldPos + roll;
  let overshoot = false;

  if (newPos > 100) {
    newPos = oldPos;
    overshoot = true;
  }

  let laddersnake = null;
  if (!overshoot && SNAKES_LADDERS[newPos] !== undefined) {
    const dest = SNAKES_LADDERS[newPos];
    laddersnake = { from: newPos, to: dest, type: dest > newPos ? "tangga" : "ular" };
    newPos = dest;
  }

  player.position = newPos;
  const won = newPos >= 100;

  if (game.mode === "multi" && !won) {
    game.turnIndex = (game.turnIndex + 1) % game.players.length;
  }

  if (won) {
    game.status = "finished";
  }

  saveAll(all);

  const nextPlayer = game.mode === "multi" && !won ? game.players[game.turnIndex] : null;

  return {
    roll,
    oldPos,
    newPos,
    overshoot,
    laddersnake,
    won,
    playerName: player.name,
    nextPlayer,
    players: game.players,
    mode: game.mode,
  };
}

module.exports = {
  getGame,
  createGame,
  joinGame,
  beginGame,
  cancelGame,
  rollDice,
  generateBoardImage,
};

```


# FILE: ./lib/tebak.js

```js
const activeGames = new Map();

const WORDS = ["kucing", "gitar", "sekolah", "gunung", "lampu", "sepatu", "bantal", "payung", "kalkulator", "jendela"];

const EMOJI_QUIZ = [
  { emoji: "🕷️👨", answer: "spiderman" },
  { emoji: "🦇👨", answer: "batman" },
  { emoji: "🚢🧊❤️", answer: "titanic" },
  { emoji: "🐜👦", answer: "antman" },
  { emoji: "🧊👸", answer: "frozen" },
  { emoji: "🦁👑", answer: "lion king" },
  { emoji: "🐟🔍", answer: "finding nemo" },
  { emoji: "👻🚫", answer: "ghostbusters" },
  { emoji: "🍫🏭", answer: "charlie and the chocolate factory" },
  { emoji: "🦖🏞️", answer: "jurassic park" },
];

const BENAR_SALAH = [
  { statement: "Matahari terbit dari barat", answer: "salah" },
  { statement: "Air mendidih di suhu 100 derajat Celsius", answer: "benar" },
  { statement: "Indonesia punya 34 provinsi (sebelum pemekaran baru)", answer: "benar" },
  { statement: "Ikan bisa hidup tanpa air", answer: "salah" },
  { statement: "Gajah adalah hewan terbesar di darat", answer: "benar" },
  { statement: "Bulan lebih besar dari Bumi", answer: "salah" },
  { statement: "Manusia punya 206 tulang", answer: "benar" },
  { statement: "Lebah madu tidak bisa terbang", answer: "salah" },
];

const CAK_LONTONG = [
  { q: "Kenapa kalkulator gak pernah sakit hati?", a: "karena dia gak punya perasaan" },
  { q: "Apa bedanya kamu sama kopi?", a: "kopi bisa bikin melek, kamu bikin baper" },
  { q: "Kenapa laptop gak pernah nangis?", a: "karena dia punya windows" },
  { q: "Kenapa semut gak pernah sakit gigi?", a: "karena semut gak punya gigi" },
  { q: "Apa yang bikin sandal jepit sedih?", a: "kalau ditinggal sebelah" },
];

const TRUTH_PROMPTS = [
  "Kapan terakhir kali kamu bohong ke orang tua?",
  "Siapa orang yang paling kamu kagumi diam-diam?",
  "Pernah nggak kamu nyontek waktu ujian?",
  "Apa hal paling memalukan yang pernah kamu lakuin?",
  "Siapa mantan yang paling susah dilupain?",
  "Pernah nggak kamu naksir temen sendiri?",
];

const DARE_PROMPTS = [
  "Kirim voice note nyanyi lagu apa aja sekarang",
  "Ganti nama WA kamu jadi 'Raja/Ratu Micin' selama 1 jam",
  "Kirim foto selfie paling jelek yang kamu punya",
  "Telepon orang random di kontak, bilang 'aku sayang kamu', terus tutup",
  "Ketik pesan tanpa spasi sepanjang 3 kalimat",
];

const KHODAM_ADJ = ["Naga", "Harimau", "Elang", "Buaya", "Kuda", "Serigala", "Merak", "Kucing", "Beruang", "Rajawali"];
const KHODAM_NOUN = ["Petir Nusantara", "Api Abadi", "Angin Selatan", "Bayangan Malam", "Cahaya Fajar", "Baja Hitam", "Es Purba", "Emas Kuno"];
const KHODAM_POWER = [
  "mengubah receh jadi jajan",
  "bikin WiFi kenceng tiba-tiba",
  "nyari colokan di tempat umum",
  "tau kapan gebetan online",
  "gak pernah kehabisan kuota",
  "auto menang war tiket konser",
  "dapet parkiran deket pas rame",
];

function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function shuffleWord(word) {
  const letters = word.split("");
  for (let i = letters.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [letters[i], letters[j]] = [letters[j], letters[i]];
  }
  const shuffled = letters.join("");
  return shuffled === word ? shuffleWord(word) : shuffled;
}

function getActiveGame(groupId) {
  return activeGames.get(groupId) || null;
}

function stopGame(groupId) {
  return activeGames.delete(groupId);
}

function startGame(groupId, type) {
  if (activeGames.has(groupId)) return null;

  let game = { type, createdAt: Date.now() };

  if (type === "math") {
    const a = Math.floor(Math.random() * 50) + 1;
    const b = Math.floor(Math.random() * 50) + 1;
    const ops = ["+", "-", "*"];
    const op = pickRandom(ops);
    let result;
    if (op === "+") result = a + b;
    else if (op === "-") result = a - b;
    else result = a * b;
    game.question = `${a} ${op} ${b} = ?`;
    game.answer = String(result);
    game.prize = 10000;
  } else if (type === "tebakangka") {
    const secret = Math.floor(Math.random() * 50) + 1;
    game.secret = secret;
    game.min = 1;
    game.max = 50;
    game.question = "Aku mikirin angka antara 1-50, tebak berapa? (ketik angkanya langsung, tanpa titik)";
    game.prize = 15000;
  } else if (type === "susunkata") {
    const word = pickRandom(WORDS);
    game.question = `Susun huruf ini jadi kata: *${shuffleWord(word).toUpperCase()}*`;
    game.answer = word.toLowerCase();
    game.prize = 15000;
  } else if (type === "tebakemoji") {
    const item = pickRandom(EMOJI_QUIZ);
    game.question = `Tebak dari emoji ini: ${item.emoji}`;
    game.answer = item.answer.toLowerCase();
    game.prize = 15000;
  } else if (type === "benarsalah") {
    const item = pickRandom(BENAR_SALAH);
    game.question = `Benar atau Salah?\n"${item.statement}"`;
    game.answer = item.answer;
    game.prize = 8000;
  } else if (type === "caklontong") {
    const item = pickRandom(CAK_LONTONG);
    game.question = item.q;
    game.answer = item.a.toLowerCase();
    game.prize = 20000;
  } else {
    return null;
  }

  activeGames.set(groupId, game);
  return game;
}

function normalize(text) {
  return (text || "").trim().toLowerCase();
}

function checkAnswer(groupId, text) {
  const game = activeGames.get(groupId);
  if (!game) return null;

  const guess = normalize(text);

  if (game.type === "tebakangka") {
    const num = parseInt(text.trim(), 10);
    if (isNaN(num)) return null;
    if (num === game.secret) {
      activeGames.delete(groupId);
      return { correct: true, prize: game.prize, answer: String(game.secret) };
    }
    const hint = num < game.secret ? "⬆️ Lebih besar lagi!" : "⬇️ Lebih kecil lagi!";
    return { correct: false, hint };
  }

  if (guess === game.answer) {
    activeGames.delete(groupId);
    return { correct: true, prize: game.prize, answer: game.answer };
  }

  return { correct: false };
}

function getTruth() {
  return pickRandom(TRUTH_PROMPTS);
}

function getDare() {
  return pickRandom(DARE_PROMPTS);
}

function getKhodam(name) {
  const adj = pickRandom(KHODAM_ADJ);
  const noun = pickRandom(KHODAM_NOUN);
  const power = pickRandom(KHODAM_POWER);
  return `🔮 Khodam ${name ? "milik " + name : "kamu"} adalah...\n\n*${adj} ${noun}*\n\n✨ Kekuatan: ${power}`;
}

module.exports = {
  getActiveGame,
  stopGame,
  startGame,
  checkAnswer,
  getTruth,
  getDare,
  getKhodam,
};

```


# FILE: ./lib/ai.js

```js
const axios = require("axios");
const config = require("../config");

async function askGemini(prompt) {
  const apiKey = config.geminiApiKey;
  if (!apiKey || apiKey.includes("AQ.Ab8RN6IEhddsh_mx8m6goJb9ff5GC9Jwv3bCJ7hfw1h07uSLRg")) {
    throw new Error("API key Gemini belum diisi di config.js");
  }

  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

  const payload = {
    contents: [{ parts: [{ text: prompt }] }],
  };

  let res;
  try {
    res = await axios.post(url, payload, {
      headers: { "Content-Type": "application/json" },
      timeout: 30000,
    });
  } catch (e) {
    const apiError = e.response?.data?.error?.message;
    throw new Error(apiError || e.message);
  }

  const data = res.data;
  if (!data.candidates || !data.candidates.length) {
    throw new Error("Respon diblokir atau kosong dari Gemini.");
  }

  const candidate = data.candidates[0];
  const text = candidate?.content?.parts?.[0]?.text;
  if (!text) {
    throw new Error("Respon diblokir safety filter atau kosong.");
  }

  return text;
}

module.exports = { askGemini };

```


# FILE: ./lib/iqc.js

```js
const Jimp = require("jimp");
const axios = require("axios");

const emojiCache = new Map();

function isEmoji(g) {
  return /\p{Extended_Pictographic}/u.test(g);
}

function toCodepoints(g, stripFE0F) {
  return Array.from(g)
    .map((c) => c.codePointAt(0))
    .filter((cp) => !(stripFE0F && cp === 0xfe0f))
    .map((cp) => cp.toString(16))
    .join("-");
}

async function fetchEmojiImage(g) {
  if (emojiCache.has(g)) return emojiCache.get(g);
  for (const cp of [toCodepoints(g, false), toCodepoints(g, true)]) {
    try {
      const url = `https://cdn.jsdelivr.net/gh/jdecked/twemoji@latest/assets/72x72/${cp}.png`;
      const res = await axios.get(url, { responseType: "arraybuffer", timeout: 8000 });
      const buf = Buffer.from(res.data);
      emojiCache.set(g, buf);
      return buf;
    } catch (e) {
      continue;
    }
  }
  emojiCache.set(g, null);
  return null;
}

function parseReactions(input) {
  if (!input) return [];
  const segmenter = new Intl.Segmenter(undefined, { granularity: "grapheme" });
  const graphemes = Array.from(segmenter.segment(input), (s) => s.segment);
  return graphemes.filter(isEmoji).slice(0, 6);
}

function setPx(img, x, y, colorInt) {
  if (x < 0 || y < 0 || x >= img.bitmap.width || y >= img.bitmap.height) return;
  img.setPixelColor(colorInt, Math.round(x), Math.round(y));
}

function drawRoundedRect(img, x, y, w, h, radius, colorInt) {
  const r = Math.min(radius, w / 2, h / 2);
  for (let py = y; py < y + h; py++) {
    for (let px = x; px < x + w; px++) {
      let inside = true;
      if (px < x + r && py < y + r) {
        inside = (px - (x + r)) ** 2 + (py - (y + r)) ** 2 <= r * r;
      } else if (px > x + w - r && py < y + r) {
        inside = (px - (x + w - r)) ** 2 + (py - (y + r)) ** 2 <= r * r;
      } else if (px < x + r && py > y + h - r) {
        inside = (px - (x + r)) ** 2 + (py - (y + h - r)) ** 2 <= r * r;
      } else if (px > x + w - r && py > y + h - r) {
        inside = (px - (x + w - r)) ** 2 + (py - (y + h - r)) ** 2 <= r * r;
      }
      if (inside) setPx(img, px, py, colorInt);
    }
  }
}

function drawCircle(img, cx, cy, radius, colorInt) {
  for (let y = cy - radius; y <= cy + radius; y++) {
    for (let x = cx - radius; x <= cx + radius; x++) {
      if ((x - cx) ** 2 + (y - cy) ** 2 <= radius * radius) setPx(img, x, y, colorInt);
    }
  }
}

function wrapText(font, text, maxWidth) {
  const words = text.split(" ");
  const lines = [];
  let line = "";
  for (const word of words) {
    const test = line ? line + " " + word : word;
    if (Jimp.measureText(font, test) > maxWidth && line) {
      lines.push(line);
      line = word;
    } else {
      line = test;
    }
  }
  if (line) lines.push(line);
  return lines;
}

function drawStatusBar(img, width) {
  const white = Jimp.cssColorToHex("#ffffff");
  const now = new Date();
  const timeStr = now.getHours().toString().padStart(2, "0") + ":" + now.getMinutes().toString().padStart(2, "0");

  const barX = width - 130;
  for (let i = 0; i < 4; i++) {
    const bh = 6 + i * 4;
    for (let yy = 0; yy < bh; yy++) {
      for (let xx = 0; xx < 5; xx++) {
        setPx(img, barX + i * 8 + xx, 30 - yy, white);
      }
    }
  }

  const wifiX = width - 85;
  for (let i = 0; i < 3; i++) {
    drawCircle(img, wifiX + i * 10, 26 - i * 3, 2, white);
  }

  const battX = width - 55;
  for (let xx = 0; xx < 32; xx++) {
    setPx(img, battX + xx, 14, white);
    setPx(img, battX + xx, 26, white);
  }
  for (let yy = 14; yy <= 26; yy++) {
    setPx(img, battX, yy, white);
    setPx(img, battX + 31, yy, white);
  }
  for (let xx = 3; xx < 28; xx++) {
    for (let yy = 17; yy <= 23; yy++) {
      setPx(img, battX + xx, yy, white);
    }
  }
  for (let yy = 18; yy <= 22; yy++) {
    setPx(img, battX + 33, yy, white);
  }

  return timeStr;
}

const BUBBLE_COLOR = "#262628";
const BG_TOP = "#0a0a0a";
const BG_BOTTOM = "#1a1a2e";
const MAX_TEXT_LENGTH = 500;

async function generateIqcImage({ texts, time, reactions, showStatusBar = true }) {
  const width = 720;
  const sideMargin = 40;
  const bubblePaddingX = 22;
  const bubblePaddingY = 16;
  const maxBubbleWidth = width - sideMargin * 2 - bubblePaddingX * 2;
  const bubbleGap = 14;
  const reactionBarHeight = 44;

  const font = await Jimp.loadFont(Jimp.FONT_SANS_32_WHITE);
  const fontTime = await Jimp.loadFont(Jimp.FONT_SANS_16_WHITE);
  const lineHeight = 38;

  const cleanTexts = texts
    .map((t) => t.trim().slice(0, MAX_TEXT_LENGTH))
    .filter((t) => t.length > 0);
  if (cleanTexts.length === 0) cleanTexts.push("...");

  const bubbles = cleanTexts.map((text) => {
    const lines = wrapText(font, text, maxBubbleWidth);
    let bubbleWidth = 0;
    for (const l of lines) bubbleWidth = Math.max(bubbleWidth, Jimp.measureText(font, l));
    bubbleWidth = Math.min(bubbleWidth + bubblePaddingX * 2, width - sideMargin * 2);
    bubbleWidth = Math.max(bubbleWidth, 120);
    const timeWidth = Jimp.measureText(fontTime, time || "");
    bubbleWidth = Math.max(bubbleWidth, timeWidth + bubblePaddingX * 2 + 20);
    const bubbleHeight = lines.length * lineHeight + bubblePaddingY * 2 + 22;
    return { lines, width: bubbleWidth, height: bubbleHeight };
  });

  const hasReactions = reactions && reactions.length > 0;
  let totalHeight = showStatusBar ? 70 : 30;
  for (const b of bubbles) {
    if (hasReactions) totalHeight += reactionBarHeight + 8;
    totalHeight += b.height + bubbleGap;
  }
  totalHeight += 30;

  const image = new Jimp(width, totalHeight, BG_TOP);
  const topColor = Jimp.intToRGBA(Jimp.cssColorToHex(BG_TOP));
  const bottomColor = Jimp.intToRGBA(Jimp.cssColorToHex(BG_BOTTOM));
  for (let y = 0; y < totalHeight; y++) {
    const ratio = y / totalHeight;
    const r = Math.round(topColor.r + (bottomColor.r - topColor.r) * ratio);
    const g = Math.round(topColor.g + (bottomColor.g - topColor.g) * ratio);
    const bl = Math.round(topColor.b + (bottomColor.b - topColor.b) * ratio);
    const rowColor = Jimp.rgbaToInt(r, g, bl, 255);
    for (let x = 0; x < width; x++) setPx(image, x, y, rowColor);
  }

  let cursorY = 20;
  if (showStatusBar) {
    drawStatusBar(image, width);
    cursorY = 60;
  }

  const bubbleColorInt = Jimp.cssColorToHex(BUBBLE_COLOR);
  const reactionBgInt = Jimp.rgbaToInt(255, 255, 255, 235);

  for (const bubble of bubbles) {
    if (hasReactions) {
      const emojiSize = 26;
      const barPaddingX = 12;
      const barWidth = reactions.length * (emojiSize + 6) + barPaddingX * 2;
      const barX = sideMargin;
      drawRoundedRect(image, barX, cursorY, barWidth, reactionBarHeight, reactionBarHeight / 2, reactionBgInt);
      let ex = barX + barPaddingX;
      for (const emo of reactions) {
        try {
          const buf = await fetchEmojiImage(emo);
          if (buf) {
            const emojiImg = await Jimp.read(buf);
            emojiImg.resize(emojiSize, emojiSize);
            image.composite(emojiImg, Math.round(ex), Math.round(cursorY + (reactionBarHeight - emojiSize) / 2));
          }
        } catch (e) {}
        ex += emojiSize + 6;
      }
      cursorY += reactionBarHeight + 8;
    }

    drawRoundedRect(image, sideMargin, cursorY, bubble.width, bubble.height, 20, bubbleColorInt);

    let ty = cursorY + bubblePaddingY;
    for (const line of bubble.lines) {
      image.print(font, sideMargin + bubblePaddingX, ty, line);
      ty += lineHeight;
    }

    if (time) {
      const tw = Jimp.measureText(fontTime, time);
      image.print(
        fontTime,
        sideMargin + bubble.width - bubblePaddingX - tw,
        cursorY + bubble.height - 26,
        time
      );
    }

    cursorY += bubble.height + bubbleGap;
  }

  return image.getBufferAsync(Jimp.MIME_PNG);
}

module.exports = { generateIqcImage, parseReactions, MAX_TEXT_LENGTH };

```


# FILE: ./handler.js

```js
const fs = require("fs");
const path = require("path");
const { downloadMediaMessage, jidNormalizedUser } = require("@whiskeysockets/baileys");
const axios = require("axios");
const config = require("./config");
const db = require("./lib/database");
const { generateBratImage } = require("./lib/brat");
const { bufferToSticker } = require("./lib/sticker");
const { generateFakeCallImage } = require("./lib/fakecall");
const { generateIqcImage, parseReactions } = require("./lib/iqc");
const economy = require("./lib/economy");
const ular = require("./lib/ulartangga");
const tebak = require("./lib/tebak");
const { askGemini } = require("./lib/ai");
const {
  searchYoutube,
  downloadYoutubeAudio,
  downloadYoutubeVideo,
  tiktokNoWatermark,
  generateQuotly,
} = require("./lib/downloader");

const startTime = Date.now();
const kerjaCooldown = new Map();
const KERJA_COOLDOWN_MS = 10000;
const OWNER_EFFECTIVE_LEVEL = 10000000;
const MAX_LEVEL = 1000;

function getText(msg) {
  const m = msg.message;
  if (!m) return "";
  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    ""
  );
}

function getQuoted(msg) {
  const ctx = msg.message?.extendedTextMessage?.contextInfo;
  if (!ctx || !ctx.quotedMessage) return null;
  return {
    key: {
      remoteJid: msg.key.remoteJid,
      id: ctx.stanzaId,
      participant: ctx.participant,
      fromMe: false,
    },
    message: ctx.quotedMessage,
  };
}

async function isSenderAdmin(sock, groupId, sender) {
  const metadata = await sock.groupMetadata(groupId);
  const senderJid = jidNormalizedUser(sender);
  const participant = metadata.participants.find(
    (p) => jidNormalizedUser(p.id) === senderJid || jidNormalizedUser(p.lid || "") === senderJid
  );
  return participant?.admin === "admin" || participant?.admin === "superadmin";
}

async function isBotAdmin(sock, groupId) {
  const metadata = await sock.groupMetadata(groupId);
  const botJid = jidNormalizedUser(sock.user.id);
  const botLid = sock.user.lid ? jidNormalizedUser(sock.user.lid) : null;
  const participant = metadata.participants.find((p) => {
    const pJid = jidNormalizedUser(p.id);
    const pLid = p.lid ? jidNormalizedUser(p.lid) : null;
    return pJid === botJid || (botLid && pLid === botLid) || (botLid && pJid === botLid) || (pLid && pLid === botJid);
  });
  return participant?.admin === "admin" || participant?.admin === "superadmin";
}

async function handleUlarRoll(sock, msg, from, sender) {
  const result = ular.rollDice(from, sender);
  if (result.error) {
    await sock.sendMessage(from, { text: result.error }, { quoted: msg });
    return;
  }

  let text = `🎲 ${result.playerName} lempar dadu: *${result.roll}*\n`;
  if (result.overshoot) {
    text += `Kelebihan langkah, posisi tetap di ${result.oldPos}.`;
  } else {
    text += `${result.oldPos} ➜ ${result.newPos}`;
    if (result.laddersnake) {
      const emoji = result.laddersnake.type === "tangga" ? "🪜 Naik tangga!" : "🐍 Kena ular, turun!";
      text += `\n${emoji} ${result.laddersnake.from} ➜ ${result.laddersnake.to}`;
    }
  }

  if (result.won) {
    text += `\n\n🏆 *${result.playerName} MENANG!* Game selesai.`;
  } else if (result.mode === "multi" && result.nextPlayer) {
    text += `\n\nGiliran selanjutnya: *${result.nextPlayer.name}*`;
  } else if (result.mode === "solo") {
    text += `\n\nKetik ${config.prefix}kocok lagi buat lanjut.`;
  }

  try {
    const img = await ular.generateBoardImage(result.players);
    await sock.sendMessage(from, { image: img, caption: text }, { quoted: msg });
  } catch (e) {
    await sock.sendMessage(from, { text }, { quoted: msg });
  }
}

function formatDuration(ms) {
  const s = Math.floor(ms / 1000) % 60;
  const m = Math.floor(ms / 60000) % 60;
  const h = Math.floor(ms / 3600000);
  return `${h}j ${m}m ${s}d`;
}

function rawNumber(jid) {
  return (jid || "").split("@")[0].split(":")[0].replace(/\D/g, "");
}

async function isOwner(sock, isGroup, groupId, jid) {
  const owner = (config.ownerNumber || "").replace(/\D/g, "");
  const ownerLid = config.ownerLid || "";

  if (ownerLid && jidNormalizedUser(jid) === jidNormalizedUser(ownerLid)) return true;
  if (owner && rawNumber(jid) === owner) return true;

  if (isGroup) {
    try {
      const metadata = await sock.groupMetadata(groupId);
      const jidNorm = jidNormalizedUser(jid);
      const participant = metadata.participants.find(
        (p) => jidNormalizedUser(p.id) === jidNorm || (p.lid && jidNormalizedUser(p.lid) === jidNorm)
      );
      if (participant) {
        if (owner && rawNumber(participant.id) === owner) return true;
        if (owner && participant.lid && rawNumber(participant.lid) === owner) return true;
        if (ownerLid && jidNormalizedUser(participant.id) === jidNormalizedUser(ownerLid)) return true;
        if (ownerLid && participant.lid && jidNormalizedUser(participant.lid) === jidNormalizedUser(ownerLid)) return true;
      }
    } catch (e) {}
  }
  return false;
}

const MENU_TEXT = (pfx) => `
╭───〔 *${config.botName}* 〕
│ Prefix: *${pfx}*
╰───────────

*✨ UMUM*
${pfx}menu - tampilkan menu ini
${pfx}ping - cek kecepatan bot
${pfx}owner - kontak owner bot
${pfx}afk [alasan] - set status afk
${pfx}brat [teks] - bikin sticker gaya "brat"
${pfx}sticker (balas/kirim gambar/video) - buat sticker
${pfx}toimg (balas sticker) - ubah sticker jadi gambar
${pfx}quotly (balas chat) - bikin sticker quote
${pfx}fakecall [nama|durasi] - gambar lucu-lucuan "sedang menelepon"\n${pfx}iqc [teks|waktu|reaksi] - bikin chat bubble ala iMessage (pisah bubble pakai ---)
${pfx}react [emoji] (balas chat) - kasih reaksi ke pesan
${pfx}unreact (balas chat) - hapus reaksi kamu
${pfx}ai [pertanyaan] - ngobrol sama AI (Gemini)

*💰 EKONOMI*
${pfx}me - lihat profil, level, token, & saldo kamu
${pfx}kerja - kerja buat dapet duit (pakai 1 token)
${pfx}levelup - naikin level pakai duit
${pfx}buytoken [jumlah] - beli token pakai duit
${pfx}transfer @user <jumlah> - transfer duit ke orang lain
${pfx}rank - cek ranking kamu
${pfx}leaderboard - top 10 orang terkaya

*🎮 GAME TEBAK-TEBAKAN*
${pfx}tebakangka - tebak angka 1-50
${pfx}math - soal matematika cepat
${pfx}benarsalah - tebak benar/salah
${pfx}susunkata - susun huruf acak
${pfx}tebakemoji - tebak dari emoji
${pfx}caklontong - tebak-tebakan receh
${pfx}stopgame - stop game yang lagi jalan (admin/owner)
${pfx}truth - pertanyaan jujur random
${pfx}dare - tantangan random
${pfx}cekkhodam [nama] - cek khodam receh-receh

*🐍 ULAR TANGGA*
${pfx}ular start solo - main sendirian
${pfx}ular start multi - buka lobby buat rame-rame
${pfx}ular join - gabung ke lobby yang lagi dibuka
${pfx}ular begin - mulai game (starter aja)
${pfx}kocok - lempar dadu (giliran kamu)
${pfx}ular status - lihat papan sekarang
${pfx}ular batal - batalin game

*🔐 KHUSUS OWNER*
${pfx}sleep - bot diam total, tidak respon siapa pun
${pfx}self - bot cuma bisa dipakai owner
${pfx}public - bot bisa dipakai semua orang (default)
${pfx}setlevel @user <angka> - set level member
${pfx}setmoney @user <angka> - set saldo member
${pfx}settoken @user <angka> - set token member
${pfx}addsultan @user - jadiin Sultan (bisa .setlevel/.setmoney/.settoken buat orang lain)
${pfx}delsultan @user - cabut status Sultan
${pfx}listsultan - lihat daftar Sultan

*🎵 DOWNLOADER*
${pfx}play [judul lagu] - cari & download lagu dari YouTube
${pfx}ytmp4 [judul/link] - download video YouTube
${pfx}tiktok [link] - download video TikTok tanpa watermark

*👥 GRUP (khusus admin, kecuali disebutkan)*
${pfx}hidetag [pesan] - tag semua member diam-diam
${pfx}kick @user - keluarkan member
${pfx}add 62xxx - tambah member
${pfx}promote @user - jadikan admin
${pfx}demote @user - turunkan admin
${pfx}groupinfo - info grup
${pfx}welcome on/off - atur pesan welcome & leave
${pfx}antilink on/off - auto-kick pengirim link
${pfx}resetwarn @user - reset peringatan antispam member
`.trim();

async function handleMessage(sock, msg) {
  try {
    if (!msg.message || msg.key.fromMe) return;

    const from = msg.key.remoteJid;
    const isGroup = from.endsWith("@g.us");
    const sender = isGroup ? msg.key.participant : from;
    const text = getText(msg).trim();
    const pfx = config.prefix;

    if (!isGroup) {
      const isOwnerDM = await isOwner(sock, false, from, sender);
      if (!isOwnerDM) {await sock.sendMessage(from, {
          text: "🚫 Bot ini jangan di-PM ya. Kalau mau pakai fiturnya, invite bot ke grup aja 🙏",
        });
        try {
          await sock.updateBlockStatus(sender, "block");
        } catch (e) {}
        return;
      }
    }

    if (isGroup) {
      const mentioned =
        msg.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
      const quotedForAfk = getQuoted(msg);
      const quotedSender = msg.message?.extendedTextMessage?.contextInfo?.participant;
      const checkTargets = [...mentioned, quotedSender].filter(Boolean);

      for (const target of checkTargets) {
        const afk = db.getAfk(target);
        if (afk) {
          const durasi = formatDuration(Date.now() - afk.time);
          await sock.sendMessage(from, {
            text: `@${target.split("@")[0]} sedang AFK sejak ${durasi} lalu.\nAlasan: ${afk.reason}`,
            mentions: [target],
          });
          break;
        }
      }

      if (db.getAfk(sender) && !text.startsWith(pfx + "afk")) {
        db.removeAfk(sender);
        await sock.sendMessage(from, {
          text: `Welcome back @${sender.split("@")[0]}, status AFK kamu sudah dihapus.`,
          mentions: [sender],
        });
      }
    }

    if (isGroup && !text.startsWith(pfx)) {
      const linkRegex = /(chat\.whatsapp\.com|https?:\/\/)/i;
      if (db.isAntilinkActive(from) && linkRegex.test(text)) {
        const senderIsAdmin = await isSenderAdmin(sock, from, sender);
        const botCanKick = await isBotAdmin(sock, from);
        if (!senderIsAdmin && botCanKick) {
          await sock.sendMessage(from, {
            text: `🔗 Link terdeteksi! @${sender.split("@")[0]} dikeluarkan otomatis (antilink aktif).`,
            mentions: [sender],
          });
          await sock.groupParticipantsUpdate(from, [sender], "remove");
          return;
        }
      }
    }

    if (isGroup && !text.startsWith(pfx) && text.trim()) {
      const activeTebak = tebak.getActiveGame(from);
      if (activeTebak) {
        const result = tebak.checkAnswer(from, text);
        if (result && result.correct) {
          const winnerName = msg.pushName || "Player";
          const dataWin = economy.getUser(sender);
          economy.updateUser(sender, { money: (dataWin.money || 0) + result.prize, name: winnerName });
          await sock.sendMessage(from, {
            text: `✅ Bener! Jawabannya *${result.answer}*.\n${winnerName} dapet Rp${result.prize.toLocaleString("id-ID")}!`,
          });
          return;
        } else if (result && result.hint) {
          await sock.sendMessage(from, { text: result.hint });
          return;
        }
      }
    }

    if (!text.startsWith(pfx)) return;

    const args = text.slice(pfx.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();
    const fullArgs = args.join(" ");
    const quoted = getQuoted(msg);
    const mentionedInMsg =
      msg.message.extendedTextMessage?.contextInfo?.mentionedJid || [];

    const senderIsOwner = await isOwner(sock, isGroup, from, sender);

    if (["sleep", "self", "public"].includes(command)) {
      if (!senderIsOwner) {
        await sock.sendMessage(from, { text: "Cuma owner yang boleh ganti mode bot." }, { quoted: msg });
        return;
      }
      db.setMode(command);
      const label =
        command === "sleep"
          ? "😴 Sleep (bot tidak merespon siapa pun kecuali owner)"
          : command === "self"
          ? "🔒 Self (cuma owner yang bisa pakai bot)"
          : "🌐 Public (semua orang bisa pakai bot)";
      await sock.sendMessage(from, { text: `Mode bot diganti ke:\n${label}` }, { quoted: msg });
      return;
    }

    const currentMode = db.getMode();
    if (!senderIsOwner) {
      if (currentMode === "sleep") return;
      if (currentMode === "self") return;
    }

    switch (command) {
      case "menu":
      case "help": {
        const menuText = MENU_TEXT(pfx);
        const mediaDir = path.join(__dirname, "media");
        fs.mkdirSync(mediaDir, { recursive: true });

        const imgPath = path.join(mediaDir, "menu.jpg");
        const audioPath = path.join(mediaDir, "honeybee.mp3");if (fs.existsSync(imgPath)) {
          await sock.sendMessage(from, { image: fs.readFileSync(imgPath), caption: menuText }, { quoted: msg });
        } else {
          await sock.sendMessage(from, { text: menuText }, { quoted: msg });
        }

        try {
          if (!fs.existsSync(audioPath)) {
            const video = await searchYoutube("honeybee");
            if (video) {
              const buffer = await downloadYoutubeAudio(video.url);
              fs.writeFileSync(audioPath, buffer);
            }
          }
          if (fs.existsSync(audioPath)) {
            await sock.sendMessage(from, {
              audio: fs.readFileSync(audioPath),
              mimetype: "audio/mp4",
              fileName: "honeybee.mp3",
            });
          }
        } catch (e) {
          // gagal ambil lagu, biarin aja, menu teks/gambar tetap udah kekirim
        }
        break;
      }

      case "ping": {
        const start = Date.now();
        await sock.sendMessage(from, { text: "Pinging..." }, { quoted: msg });
        const latency = Date.now() - start;
        await sock.sendMessage(from, {
          text: `🏓 Pong! ${latency}ms\nUptime: ${formatDuration(Date.now() - startTime)}`,
        });
        break;
      }

      case "owner": {
        await sock.sendMessage(
          from,
          {
            contacts: {
              displayName: "Owner Bot",
              contacts: [
                {
                  vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:Owner Bot\nTEL;type=CELL;type=VOICE;waid=${config.ownerNumber}:+${config.ownerNumber}\nEND:VCARD`,
                },
              ],
            },
          },
          { quoted: msg }
        );
        break;
      }

      case "afk": {
        db.setAfk(sender, fullArgs || "Tidak ada alasan");
        await sock.sendMessage(from, {
          text: `✅ Status AFK diset untuk @${sender.split("@")[0]}\nAlasan: ${fullArgs || "Tidak ada alasan"}`,
          mentions: [sender],
        }, { quoted: msg });
        break;
      }

      case "brat": {
        if (!fullArgs) {
          await sock.sendMessage(from, { text: `Contoh: ${pfx}brat teks kamu di sini` }, { quoted: msg });
          break;
        }
        const img = await generateBratImage(fullArgs);
        const stickerBuf = await bufferToSticker(img, false);
        await sock.sendMessage(from, { sticker: stickerBuf }, { quoted: msg });
        break;
      }

      case "fakecall": {
        let targetName = msg.pushName || "Unknown";
        let targetDuration = "00:00";
        if (fullArgs) {
          const parts = fullArgs.split("|");
          targetName = parts[0].trim() || targetName;
          if (parts[1]) targetDuration = parts[1].trim();
        }

        let avatarBuffer = null;

        const mediaSource = quoted && quoted.message && quoted.message.imageMessage ? quoted : null;
        if (mediaSource) {
          try {
            avatarBuffer = await downloadMediaMessage(mediaSource, "buffer", {});
          } catch (e) {
            avatarBuffer = null;
          }
        }

        if (!avatarBuffer) {
          const picTargetJid = mentionedInMsg[0] || sender;
          try {
            const ppUrl = await sock.profilePictureUrl(picTargetJid, "image");
            const resp = await axios.get(ppUrl, { responseType: "arraybuffer", timeout: 15000 });
            avatarBuffer = Buffer.from(resp.data);
          } catch (e) {
            avatarBuffer = null;
          }
        }

        const img = await generateFakeCallImage({ name: targetName, duration: targetDuration, avatarBuffer });
        await sock.sendMessage(from, { image: img, caption: `📞 Sedang menelepon ${targetName}...` }, { quoted: msg });
        break;
      }

      case "me": {
        const targetJid = mentionedInMsg[0] || sender;
        const targetIsOwner = await isOwner(sock, isGroup, from, targetJid);
        const data = economy.getUser(targetJid);
        const levelText = targetIsOwner ? "MAX 👑" : data.level;
        const tokenText = targetIsOwner ? "∞" : data.token;
        const moneyText = "Rp" + (data.money || 0).toLocaleString("id-ID");

        const caption = `👤 *Profile*\n\nToken: ${tokenText}\nLevel: ${levelText}\nMoney: ${moneyText}`;

        let avatarBuffer = null;
        try {
          const ppUrl = await sock.profilePictureUrl(targetJid, "image");
          const resp = await axios.get(ppUrl, { responseType: "arraybuffer", timeout: 15000 });
          avatarBuffer = Buffer.from(resp.data);
        } catch (e) {
          avatarBuffer = null;
        }

        if (avatarBuffer) {
          await sock.sendMessage(from, { image: avatarBuffer, caption }, { quoted: msg });
        } else {
          await sock.sendMessage(from, { text: caption }, { quoted: msg });
        }
        break;
      }

      case "kerja": {
        const lastKerja = kerjaCooldown.get(sender) || 0;
        const sinceLastKerja = Date.now() - lastKerja;
        if (sinceLastKerja < KERJA_COOLDOWN_MS) {
          const sisaDetik = Math.ceil((KERJA_COOLDOWN_MS - sinceLastKerja) / 1000);
          await sock.sendMessage(from, { text: `⏳ Sabar dulu, tunggu ${sisaDetik} detik lagi buat kerja.` }, { quoted: msg });
          break;
        }
        kerjaCooldown.set(sender, Date.now());

        if (senderIsOwner) {
          const gajiOwner = (Math.floor(Math.random() * 10000) + 5000) * OWNER_EFFECTIVE_LEVEL;
          const dataOwner = economy.getUser(sender);
          economy.updateUser(sender, { money: (dataOwner.money || 0) + gajiOwner });
          await sock.sendMessage(from, {
            text: `👑 Owner kerja (level MAX, token unlimited)\n💵 Dapat Rp${gajiOwner.toLocaleString("id-ID")}`,
          }, { quoted: msg });
          break;
        }

        const dataKerja = economy.getUser(sender);
        if (dataKerja.token <= 0) {
          await sock.sendMessage(from, {
            text: "❌ Token kamu habis hari ini. Tunggu reset besok atau beli token pakai " + pfx + "buytoken.",
          }, { quoted: msg });
          break;
        }

        const gaji = (Math.floor(Math.random() * 10000) + 5000) * dataKerja.level;
        const newMoney = (dataKerja.money || 0) + gaji;
        const newToken = dataKerja.token - 1;
        let leveledUp = false;
        let newLevel = dataKerja.level;
        if (Math.random() < 0.15 && dataKerja.level < MAX_LEVEL) {
          leveledUp = true;
          newLevel = dataKerja.level + 1;
        }
        economy.updateUser(sender, { money: newMoney, token: newToken, level: newLevel });

        let resultText = `💼 Kamu kerja dan dapat Rp${gaji.toLocaleString("id-ID")}\n🎫 Sisa token: ${newToken}`;
        if (leveledUp) resultText += `\n🎉 Selamat! Level naik jadi ${newLevel}!`;
        await sock.sendMessage(from, { text: resultText }, { quoted: msg });
        break;
      }

      case "levelup": {
        if (senderIsOwner) {
          await sock.sendMessage(from, { text: "👑 Kamu owner, level kamu udah MAX." }, { quoted: msg });
          break;
        }
        const dataLvl = economy.getUser(sender);
        if (dataLvl.level >= MAX_LEVEL) {
          await sock.sendMessage(from, { text: `Level kamu udah maksimal (${MAX_LEVEL}).` }, { quoted: msg });
          break;
        }
        const cost = dataLvl.level * 100000;
        if ((dataLvl.money || 0) < cost) {
          await sock.sendMessage(from, {
            text: `❌ Duit kamu kurang. Butuh Rp${cost.toLocaleString("id-ID")} buat naik ke level ${dataLvl.level + 1}.`,
          }, { quoted: msg });
          break;
        }
        economy.updateUser(sender, { money: dataLvl.money - cost, level: dataLvl.level + 1 });
        await sock.sendMessage(from, {
          text: `🎉 Level naik jadi ${dataLvl.level + 1}! Sisa duit: Rp${(dataLvl.money - cost).toLocaleString("id-ID")}`,
        }, { quoted: msg });
        break;
      }

      case "buytoken": {
        if (senderIsOwner) {
          await sock.sendMessage(from, { text: "👑 Kamu owner, token kamu udah unlimited." }, { quoted: msg });
          break;
        }
        const jumlah = parseInt(fullArgs, 10);
        if (!jumlah || jumlah <= 0) {
          await sock.sendMessage(from, { text: `Contoh: ${pfx}buytoken 5` }, { quoted: msg });
          break;
        }
        const hargaPerToken = 5000;
        const totalHarga = jumlah * hargaPerToken;
        const dataBeli = economy.getUser(sender);
        if ((dataBeli.money || 0) < totalHarga) {
          await sock.sendMessage(from, {
            text: `❌ Duit kamu kurang. Butuh Rp${totalHarga.toLocaleString("id-ID")} buat beli ${jumlah} token.`,
          }, { quoted: msg });
          break;
        }
        economy.updateUser(sender, {
          money: dataBeli.money - totalHarga,
          token: (dataBeli.token || 0) + jumlah,
        });
        await sock.sendMessage(from, {
          text: `✅ Berhasil beli ${jumlah} token seharga Rp${totalHarga.toLocaleString("id-ID")}.`,
        }, { quoted: msg });
        break;
      }

      case "setlevel":
      case "setmoney":
      case "settoken": {
        const senderIsSultan = db.isSultan(sender);
        if (!senderIsOwner && !senderIsSultan) {
          await sock.sendMessage(from, { text: "Cuma owner/sultan yang boleh pakai perintah ini." }, { quoted: msg });
          break;
        }
        const targetSet = mentionedInMsg[0] || quoted?.key?.participant || sender;

        if (!senderIsOwner && senderIsSultan && targetSet === sender) {
          await sock.sendMessage(from, { text: "Sultan cuma bisa ngeset orang lain, nggak bisa ngeset diri sendiri." }, { quoted: msg });
          break;
        }

        const partsSet = fullArgs.trim().split(/\s+/);
        const valueSet = parseInt(partsSet[partsSet.length - 1], 10);
        if (isNaN(valueSet)) {
          await sock.sendMessage(from, { text: `Contoh: ${pfx}${command} @user 5` }, { quoted: msg });
          break;
        }
        const field = command === "setlevel" ? "level" : command === "setmoney" ? "money" : "token";
        economy.updateUser(targetSet, { [field]: valueSet });
        await sock.sendMessage(from, {
          text: `✅ ${field} @${targetSet.split("@")[0]} diset jadi ${valueSet}`,
          mentions: [targetSet],
        }, { quoted: msg });
        break;
      }

      case "addsultan":
      case "delsultan": {
        if (!senderIsOwner) {
          await sock.sendMessage(from, { text: "Cuma owner yang boleh atur sultan." }, { quoted: msg });
          break;
        }
        const targetSultan = mentionedInMsg[0] || quoted?.key?.participant;
        if (!targetSultan) {
          await sock.sendMessage(from, { text: `Tag/reply orangnya, contoh: ${pfx}${command} @user` }, { quoted: msg });
          break;
        }
        if (command === "addsultan") {
          db.addSultan(targetSultan);
          await sock.sendMessage(from, {
            text: `👑 @${targetSultan.split("@")[0]} sekarang jadi Sultan.`,
            mentions: [targetSultan],
          }, { quoted: msg });
        } else {
          db.removeSultan(targetSultan);
          await sock.sendMessage(from, {
            text: `✅ @${targetSultan.split("@")[0]} udah bukan Sultan lagi.`,
            mentions: [targetSultan],
          }, { quoted: msg });
        }
        break;
      }

      case "listsultan": {
        const list = db.getSultanList();
        if (list.length === 0) {
          await sock.sendMessage(from, { text: "Belum ada Sultan sama sekali." }, { quoted: msg });
          break;
        }
        await sock.sendMessage(from, {
          text: `👑 *Daftar Sultan*\n\n${list.map((j) => "@" + j.split("@")[0]).join("\n")}`,
          mentions: list,
        }, { quoted: msg });
        break;
      }

      case "ular": {
        if (!isGroup) {
          await sock.sendMessage(from, { text: "Fitur ular tangga cuma bisa dipakai di grup." }, { quoted: msg });
          break;
        }
        const [sub, ...subArgsArr] = fullArgs.trim().split(/\s+/);
        const subArgs = subArgsArr.join(" ");
        const playerName = msg.pushName || "Player";

        if (sub === "start") {
          const existing = ular.getGame(from);
          if (existing && existing.status !== "finished") {
            await sock.sendMessage(from, { text: `Masih ada game yang jalan/nunggu. Ketik ${pfx}ular batal dulu kalau mau mulai baru.` }, { quoted: msg });
            break;
          }
          const mode = subArgs.toLowerCase() === "multi" ? "multi" : "solo";
          ular.createGame(from, mode, sender, playerName);
          if (mode === "solo") {
            const game = ular.getGame(from);
            const img = await ular.generateBoardImage(game.players);
            await sock.sendMessage(from, {
              image: img,
              caption: `🐍 Ular Tangga solo dimulai!\nKetik ${pfx}kocok buat lempar dadu.`,
            }, { quoted: msg });
          } else {
            await sock.sendMessage(from, {
              text: `🐍 Lobby ular tangga dibuka oleh ${playerName}!\nKetik ${pfx}ular join buat gabung.\nKalau udah cukup, ${playerName} ketik ${pfx}ular begin buat mulai.`,
            }, { quoted: msg });
          }
          break;
        }

        if (sub === "join") {
          const game = ular.joinGame(from, sender, playerName);
          if (!game) {
            await sock.sendMessage(from, { text: "Nggak ada lobby yang lagi dibuka. Mulai dulu pakai " + pfx + "ular start multi" }, { quoted: msg });
            break;
          }
          const names = game.players.map((p) => p.name).join(", ");
          await sock.sendMessage(from, { text: `✅ ${playerName} gabung!\nPemain sekarang: ${names}` }, { quoted: msg });
          break;
        }

        if (sub === "begin") {
          const gameBefore = ular.getGame(from);
          if (!gameBefore || gameBefore.status !== "waiting") {
            await sock.sendMessage(from, { text: "Nggak ada lobby yang lagi nunggu buat dimulai." }, { quoted: msg });
            break;
          }
          if (gameBefore.startedBy !== sender && !senderIsOwner) {
            await sock.sendMessage(from, { text: "Cuma yang buka lobby (atau owner) yang boleh mulai game." }, { quoted: msg });
            break;
          }
          if (gameBefore.players.length < 2) {
            await sock.sendMessage(from, { text: `Minimal 2 pemain buat mode multi. Ajak temen ketik ${pfx}ular join dulu, atau pakai ${pfx}ular start solo kalau mau sendirian.` }, { quoted: msg });
            break;
          }
          const game = ular.beginGame(from);
          const img = await ular.generateBoardImage(game.players);
          await sock.sendMessage(from, {
            image: img,
            caption: `🐍 Game dimulai! Urutan main: ${game.players.map((p) => p.name).join(" ➜ ")}\n\nGiliran pertama: *${game.players[0].name}*, ketik ${pfx}kocok`,
          }, { quoted: msg });
          break;
        }

        if (sub === "status") {
          const game = ular.getGame(from);
          if (!game) {
            await sock.sendMessage(from, { text: "Nggak ada game aktif di grup ini." }, { quoted: msg });
            break;
          }
          const img = await ular.generateBoardImage(game.players);
          const posText = game.players.map((p) => `${p.name}: ${p.position}`).join("\n");
          let statusText = `📋 Status game (${game.mode}):\n${posText}`;
          if (game.mode === "multi" && game.status === "playing") {
            statusText += `\n\nGiliran: ${game.players[game.turnIndex].name}`;
          }
          await sock.sendMessage(from, { image: img, caption: statusText }, { quoted: msg });
          break;
        }

        if (sub === "batal" || sub === "cancel") {
          const game = ular.getGame(from);
          if (!game) {
            await sock.sendMessage(from, { text: "Nggak ada game buat dibatalin." }, { quoted: msg });
            break;
          }
          if (game.startedBy !== sender && !senderIsOwner) {
            await sock.sendMessage(from, { text: "Cuma yang buka game (atau owner) yang boleh batalin." }, { quoted: msg });
            break;
          }
          ular.cancelGame(from);
          await sock.sendMessage(from, { text: "🚫 Game ular tangga dibatalin." }, { quoted: msg });
          break;
        }

        if (sub === "kocok") {
          await handleUlarRoll(sock, msg, from, sender);
          break;
        }

        await sock.sendMessage(from, {
          text: `Contoh: ${pfx}ular start solo | ${pfx}ular start multi | ${pfx}ular join | ${pfx}ular begin | ${pfx}ular status | ${pfx}ular batal`,
        }, { quoted: msg });
        break;
      }

      case "kocok": {
        if (!isGroup) {
          await sock.sendMessage(from, { text: "Fitur ular tangga cuma bisa dipakai di grup." }, { quoted: msg });
          break;
        }
        await handleUlarRoll(sock, msg, from, sender);
        break;
      }

      case "tebakangka":
      case "math":
      case "benarsalah":
      case "susunkata":
      case "tebakemoji":
      case "caklontong": {
        if (!isGroup) {
          await sock.sendMessage(from, { text: "Game tebak-tebakan cuma bisa di grup." }, { quoted: msg });
          break;
        }
        const game = tebak.startGame(from, command);
        if (!game) {
          await sock.sendMessage(from, { text: `Masih ada game aktif. Jawab dulu atau ketik ${pfx}stopgame.` }, { quoted: msg });
          break;
        }
        await sock.sendMessage(from, { text: `🎲 ${game.question}\n\n💰 Hadiah: Rp${game.prize.toLocaleString("id-ID")}` }, { quoted: msg });
        break;
      }

      case "stopgame": {
        if (!isGroup) {
          await sock.sendMessage(from, { text: "Fitur ini cuma bisa di grup." }, { quoted: msg });
          break;
        }
        const activeCheck = tebak.getActiveGame(from);
        if (!activeCheck) {
          await sock.sendMessage(from, { text: "Nggak ada game yang lagi jalan." }, { quoted: msg });
          break;
        }
        const isAdminCheck = await isSenderAdmin(sock, from, sender);
        if (!isAdminCheck && !senderIsOwner) {
          await sock.sendMessage(from, { text: "Cuma admin/owner yang boleh stop game." }, { quoted: msg });
          break;
        }
        tebak.stopGame(from);
        await sock.sendMessage(from, { text: "🛑 Game dihentikan." }, { quoted: msg });
        break;
      }

      case "truth": {
        await sock.sendMessage(from, { text: `🤔 *Truth:*\n${tebak.getTruth()}` }, { quoted: msg });
        break;
      }

      case "dare": {
        await sock.sendMessage(from, { text: `🔥 *Dare:*\n${tebak.getDare()}` }, { quoted: msg });
        break;
      }

      case "cekkhodam": {
        const namaKhodam = fullArgs || msg.pushName || "Kamu";
        await sock.sendMessage(from, { text: tebak.getKhodam(namaKhodam) }, { quoted: msg });
        break;
      }

      case "rank": {
        const targetRank = mentionedInMsg[0] || sender;
        const dataRank = economy.getUser(targetRank);
        const rankInfo = economy.getRank(targetRank);
        await sock.sendMessage(from, {
          text: `📊 Rank: #${rankInfo.rank || "-"} dari ${rankInfo.total} orang\nMoney: Rp${(dataRank.money || 0).toLocaleString("id-ID")}`,
          mentions: [targetRank],
        }, { quoted: msg });
        break;
      }

      case "leaderboard":
      case "toplocal":
      case "topbalance": {
        const top = economy.getLeaderboard(10);
        if (top.length === 0) {
          await sock.sendMessage(from, { text: "Belum ada data ekonomi sama sekali." }, { quoted: msg });
          break;
        }
        const lines = top.map((u, i) => {
          const label = u.name || ("@" + u.jid.split("@")[0]);
          return `${i + 1}. ${label} - Rp${(u.money || 0).toLocaleString("id-ID")}`;
        });
        await sock.sendMessage(from, { text: `🏆 *Top 10 Terkaya*\n\n${lines.join("\n")}` }, { quoted: msg });
        break;
      }

      case "transfer": {
        const targetTransfer = mentionedInMsg[0] || quoted?.key?.participant;
        if (!targetTransfer) {
          await sock.sendMessage(from, { text: `Contoh: ${pfx}transfer @user 50000` }, { quoted: msg });
          break;
        }
        if (targetTransfer === sender) {
          await sock.sendMessage(from, { text: "Nggak bisa transfer ke diri sendiri." }, { quoted: msg });
          break;
        }
        const partsTransfer = fullArgs.trim().split(/\s+/);
        const amountTransfer = parseInt(partsTransfer[partsTransfer.length - 1], 10);
        if (!amountTransfer || amountTransfer <= 0) {
          await sock.sendMessage(from, { text: `Contoh: ${pfx}transfer @user 50000` }, { quoted: msg });
          break;
        }
        const senderData = economy.getUser(sender);
        if ((senderData.money || 0) < amountTransfer) {
          await sock.sendMessage(from, { text: "Duit kamu nggak cukup." }, { quoted: msg });
          break;
        }
        const targetData = economy.getUser(targetTransfer);
        economy.updateUser(sender, { money: senderData.money - amountTransfer });
        economy.updateUser(targetTransfer, { money: (targetData.money || 0) + amountTransfer });
        await sock.sendMessage(from, {
          text: `✅ Berhasil transfer Rp${amountTransfer.toLocaleString("id-ID")} ke @${targetTransfer.split("@")[0]}`,
          mentions: [targetTransfer],
        }, { quoted: msg });
        break;
      }

      case "react": {
        if (!quoted) {
          await sock.sendMessage(from, { text: `Reply pesan yang mau di-react, contoh: ${pfx}react 🔥` }, { quoted: msg });
          break;
        }
        const emoji = fullArgs.trim() || "❤️";
        await sock.sendMessage(from, { react: { text: emoji, key: quoted.key } });
        break;
      }

      case "unreact": {
        if (!quoted) {
          await sock.sendMessage(from, { text: "Reply pesan yang reaksinya mau dihapus." }, { quoted: msg });
          break;
        }
        await sock.sendMessage(from, { react: { text: "", key: quoted.key } });
        break;
      }

      case "ai": {
        if (!fullArgs) {
          await sock.sendMessage(from, { text: `Contoh: ${pfx}ai jelasin cara kerja fotosintesis` }, { quoted: msg });
          break;
        }
        try {
          const answer = await askGemini(fullArgs);
          await sock.sendMessage(from, { text: `🤖 ${answer}` }, { quoted: msg });
        } catch (e) {
          await sock.sendMessage(from, { text: "❌ Gagal minta jawaban AI: " + e.message }, { quoted: msg });
        }
        break;
      }

      case "iqc": {
        if (!fullArgs) {
          await sock.sendMessage(from, {
            text: `Contoh:\n${pfx}iqc Halo bro | 20:00 | 👍❤️\n\nAtau multi-bubble:\n${pfx}iqc Halo--- Lagi apa? | 20:00`,
          }, { quoted: msg });
          break;
        }

        const parts = fullArgs.split("|").map((p) => p.trim());
        const rawText = parts[0] || "";
        const timeArg = parts[1] || (() => {
          const now = new Date();
          return now.getHours().toString().padStart(2, "0") + ":" + now.getMinutes().toString().padStart(2, "0");
        })();
        const reactionArg = parts[2] || "";

        const texts = rawText.split("---").map((t) => t.trim()).filter((t) => t.length > 0);
        if (texts.length === 0) {
          await sock.sendMessage(from, { text: "Teksnya kosong, isi dulu ya." }, { quoted: msg });
          break;
        }

        const reactions = parseReactions(reactionArg);

        try {
          const img = await generateIqcImage({ texts, time: timeArg, reactions });
          await sock.sendMessage(from, { image: img }, { quoted: msg });
        } catch (e) {
          await sock.sendMessage(from, { text: "Gagal bikin IQC: " + e.message }, { quoted: msg });
        }
        break;
      }

      case "sticker":
      case "s": {
        const target = quoted || msg;
        const type = Object.keys(target.message)[0];
        if (!["imageMessage", "videoMessage"].includes(type)) {
          await sock.sendMessage(from, { text: "Kirim/reply gambar atau video singkat dengan caption .sticker" }, { quoted: msg });
          break;
        }
        const buffer = await downloadMediaMessage(target, "buffer", {});
        const stickerBuf = await bufferToSticker(buffer, type === "videoMessage");
        await sock.sendMessage(from, { sticker: stickerBuf }, { quoted: msg });
        break;
      }

      case "toimg": {
        if (!quoted || !quoted.message.stickerMessage) {
          await sock.sendMessage(from, { text: `Reply sticker dengan caption ${pfx}toimg` }, { quoted: msg });
          break;
        }
        const buffer = await downloadMediaMessage(quoted, "buffer", {});
        await sock.sendMessage(from, { image: buffer }, { quoted: msg });
        break;
      }

      case "quotly": {
        if (!quoted) {
          await sock.sendMessage(from, { text: `Reply pesan teks dengan caption ${pfx}quotly` }, { quoted: msg });
          break;
        }
        const quotedText = getText(quoted);
        const senderName = msg.pushName || "User";
        try {
          const imgBuf = await generateQuotly({ text: quotedText, name: senderName });
          const stickerBuf = await bufferToSticker(imgBuf, false);
          await sock.sendMessage(from, { sticker: stickerBuf }, { quoted: msg });
        } catch (e) {
          await sock.sendMessage(from, { text: "Gagal bikin quotly: " + e.message }, { quoted: msg });
        }
        break;
      }

      case "play": {
        if (!fullArgs) {
          await sock.sendMessage(from, { text: `Contoh: ${pfx}play judul lagu` }, { quoted: msg });
          break;
        }
        await sock.sendMessage(from, { text: `🔎 Mencari "${fullArgs}"...` }, { quoted: msg });
        const video = await searchYoutube(fullArgs);
        if (!video) {
          await sock.sendMessage(from, { text: "Lagu tidak ditemukan." }, { quoted: msg });
          break;
        }
        try {
          const buffer = await downloadYoutubeAudio(video.url);
          await sock.sendMessage(
            from,
            {
              audio: buffer,
              mimetype: "audio/mp4",
              fileName: `${video.title}.mp3`,
            },
            { quoted: msg }
          );
        } catch (e) {
          await sock.sendMessage(from, { text: "Gagal download audio: " + e.message }, { quoted: msg });
        }
        break;
      }

      case "ytmp4": {
        if (!fullArgs) {
          await sock.sendMessage(from, { text: `Contoh: ${pfx}ytmp4 judul/link video` }, { quoted: msg });
          break;
        }
        await sock.sendMessage(from, { text: `🔎 Memproses "${fullArgs}"...` }, { quoted: msg });
        let url = fullArgs;
        if (!url.startsWith("http")) {
          const video = await searchYoutube(fullArgs);
          if (!video) {
            await sock.sendMessage(from, { text: "Video tidak ditemukan." }, { quoted: msg });
            break;
          }
          url = video.url;
        }
        try {
          const buffer = await downloadYoutubeVideo(url);
          await sock.sendMessage(from, { video: buffer, caption: "✅ Selesai" }, { quoted: msg });
        } catch (e) {
          await sock.sendMessage(from, { text: "Gagal download video: " + e.message }, { quoted: msg });
        }
        break;
      }

      case "tiktok":
      case "tt": {
        if (!fullArgs) {
          await sock.sendMessage(from, { text: `Contoh: ${pfx}tiktok https://vt.tiktok.com/xxxx` }, { quoted: msg });
          break;
        }
        try {
          const result = await tiktokNoWatermark(fullArgs);
          await sock.sendMessage(
            from,
            {
              video: { url: result.videoUrl },
              caption: `🎬 ${result.title}\n👤 ${result.author}`,
            },
            { quoted: msg }
          );
        } catch (e) {
          await sock.sendMessage(from, { text: "Gagal download TikTok: " + e.message }, { quoted: msg });
        }
        break;
      }

      case "hidetag":
      case "kick":
      case "add":
      case "promote":
      case "demote":
      case "groupinfo":
      case "welcome":
      case "antilink":
      case "resetwarn": {
        if (!isGroup) {
          await sock.sendMessage(from, { text: "Perintah ini cuma bisa dipakai di grup." }, { quoted: msg });
          break;
        }
        await handleGroupCommand(sock, msg, {
          command,
          fullArgs,
          from,
          sender,
          mentionedInMsg,
          quoted,
        });
        break;
      }

      default:
        break;
    }
  } catch (err) {
    console.error("Handler error:", err);
  }
}

async function handleGroupCommand(sock, msg, ctx) {
  const { command, fullArgs, from, sender, mentionedInMsg, quoted } = ctx;
  const pfx = config.prefix;
  const senderIsAdmin = await isSenderAdmin(sock, from, sender);

  if (command === "hidetag") {
    if (!senderIsAdmin) {
      await sock.sendMessage(from, { text: "Cuma admin yang boleh pakai hidetag." }, { quoted: msg });
      return;
    }
    const metadata = await sock.groupMetadata(from);
    const participants = metadata.participants.map((p) => p.id);
    await sock.sendMessage(from, {
      text: fullArgs || "📢 Perhatian semuanya!",
      mentions: participants,
    });
    return;
  }

  if (command === "groupinfo") {
    const metadata = await sock.groupMetadata(from);
    const admins = metadata.participants.filter((p) => p.admin).map((p) => `@${p.id.split("@")[0]}`);
    await sock.sendMessage(from, {
      text: `*${metadata.subject}*\n📝 ${metadata.desc || "-"}\n👥 Member: ${metadata.participants.length}\n👑 Admin: ${admins.join(", ")}`,
      mentions: metadata.participants.filter((p) => p.admin).map((p) => p.id),
    }, { quoted: msg });
    return;
  }

  if (!senderIsAdmin) {
    await sock.sendMessage(from, { text: "Perintah ini khusus admin grup." }, { quoted: msg });
    return;
  }

  const botCanAdmin = await isBotAdmin(sock, from);

  if (["kick", "promote", "demote"].includes(command)) {
    const target = mentionedInMsg[0] || (quoted?.key?.participant);
    if (!target) {
      await sock.sendMessage(from, { text: `Tag/reply user yang mau di-${command}.` }, { quoted: msg });
      return;
    }
    if (!botCanAdmin) {
      await sock.sendMessage(from, { text: "Bot harus jadi admin dulu untuk melakukan ini." }, { quoted: msg });
      return;
    }
    const action = command === "kick" ? "remove" : command === "promote" ? "promote" : "demote";
    await sock.groupParticipantsUpdate(from, [target], action);
    await sock.sendMessage(from, {
      text: `✅ Berhasil ${command} @${target.split("@")[0]}`,
      mentions: [target],
    });
    return;
  }

  if (command === "add") {
    if (!fullArgs) {
      await sock.sendMessage(from, { text: `Contoh: ${pfx}add 628123456789` }, { quoted: msg });
      return;
    }
    if (!botCanAdmin) {
      await sock.sendMessage(from, { text: "Bot harus jadi admin dulu untuk menambah member." }, { quoted: msg });
      return;
    }
    const number = fullArgs.replace(/\D/g, "") + "@s.whatsapp.net";
    await sock.groupParticipantsUpdate(from, [number], "add");
    await sock.sendMessage(from, { text: `✅ Berhasil menambahkan ${fullArgs}` });
    return;
  }

  if (command === "welcome") {
    const status = fullArgs.toLowerCase();
    if (!["on", "off"].includes(status)) {
      await sock.sendMessage(from, { text: `Contoh: ${pfx}welcome on / ${pfx}welcome off` }, { quoted: msg });
      return;
    }
    db.setWelcome(from, status === "on");
    await sock.sendMessage(from, { text: `✅ Welcome & leave message di-set: ${status}` });
    return;
  }

  if (command === "antilink") {
    const status = fullArgs.toLowerCase();
    if (!["on", "off"].includes(status)) {
      await sock.sendMessage(from, { text: `Contoh: ${pfx}antilink on / ${pfx}antilink off` }, { quoted: msg });
      return;
    }
    db.setAntilink(from, status === "on");
    await sock.sendMessage(from, { text: `✅ Antilink di-set: ${status}` });
    return;
  }

  if (command === "resetwarn") {
    const target = mentionedInMsg[0] || quoted?.key?.participant;
    if (!target) {
      await sock.sendMessage(from, { text: `Tag/reply user yang mau di-reset warning-nya.` }, { quoted: msg });
      return;
    }
    db.resetWarn(from, target);
    await sock.sendMessage(from, {
      text: `✅ Warning @${target.split("@")[0]} sudah direset.`,
      mentions: [target],
    });
    return;
  }
}

module.exports = { handleMessage, isBotAdmin, isSenderAdmin, isOwner, formatDuration };

```


# FILE: package.json

```json
{
  "name": "wa-bot-group",
  "version": "1.0.0",
  "description": "WhatsApp Bot dengan 20+ fitur (afk, menu, brat, play, tiktok no-wm, fakecall, dan fitur grup)",
  "main": "index.js",
  "type": "commonjs",
  "scripts": {
    "start": "node index.js"
  },
  "dependencies": {
    "@whiskeysockets/baileys": "^6.7.9",
    "@hapi/boom": "^10.0.1",
    "axios": "^1.7.7",
    "jimp": "^0.22.12",
    "fs-extra": "^11.2.0",
    "pino": "^9.4.0"
  }
}

```
