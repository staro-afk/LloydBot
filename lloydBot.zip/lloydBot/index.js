const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  jidNormalizedUser,
} = require("@whiskeysockets/baileys");
const { Boom } = require("@hapi/boom");
const pino = require("pino");
const readline = require("readline");

const config = require("./config");
const db = require("./lib/database");
const { handleMessage, isBotAdmin, isOwner } = require("./handler");

const spamTracker = new Map();
const SPAM_WINDOW_MS = 7000;
const SPAM_MAX_MSG = 5;

async function checkAntispam(sock, groupId, sender, msg) {
  const key = `${groupId}:${sender}`;
  const now = Date.now();
  const arr = (spamTracker.get(key) || []).filter((t) => now - t < SPAM_WINDOW_MS);
  arr.push(now);
  spamTracker.set(key, arr);

  if (arr.length > SPAM_MAX_MSG) {
    spamTracker.set(key, []);
    const warnCount = db.addWarn(groupId, sender);
    if (warnCount >= config.maxWarn) {
      const botCanAdmin = await isBotAdmin(sock, groupId);
      if (botCanAdmin) {
        await sock.sendMessage(groupId, {
          text: `🚫 @${sender.split("@")[0]} dikeluarkan karena spam (melebihi ${config.maxWarn}x peringatan).`,
          mentions: [sender],
        });
        await sock.groupParticipantsUpdate(groupId, [sender], "remove");
        db.resetWarn(groupId, sender);
        return;
      }
    }
    await sock.sendMessage(groupId, {
      text: `⚠️ @${sender.split("@")[0]} terdeteksi spam! Peringatan ${warnCount}/${config.maxWarn}.`,
      mentions: [sender],
    });
  }
}

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise((resolve) => rl.question(text, resolve));
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState("./session");
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    auth: state,
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
    browser: ["Ubuntu", "Chrome", "20.0.04"],
  });

  if (!sock.authState.creds.registered) {
    let phoneNumber = config.phoneNumber;
    if (!phoneNumber) {
      phoneNumber = await question(
        "Masukkan nomor WhatsApp bot (format: 628123456789, tanpa + / spasi): "
      );
    }
    phoneNumber = phoneNumber.replace(/[^0-9]/g, "");

    setTimeout(async () => {
      try {
        const code = await sock.requestPairingCode(phoneNumber);
        console.log("========================================");
        console.log(`Kode Pairing kamu: ${code}`);
        console.log("Buka WhatsApp > Perangkat Tertaut > Tautkan dengan nomor telepon,");
        console.log("lalu masukkan kode di atas.");
        console.log("========================================");
      } catch (e) {
        console.error("Gagal minta pairing code:", e);
      }
    }, 3000);
  }

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const shouldReconnect =
        new Boom(lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut;
      console.log("Koneksi terputus, reconnect:", shouldReconnect);
      if (shouldReconnect) startBot();
    } else if (connection === "open") {
      console.log(`✅ ${config.botName} berhasil terhubung ke WhatsApp!`);
    }
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    const msg = messages[0];
    if (!msg?.message || msg.key.fromMe) return;

    const from = msg.key.remoteJid;
    const isGroup = from.endsWith("@g.us");
    const sender = isGroup ? msg.key.participant : from;
    const text =
      msg.message.conversation ||
      msg.message.extendedTextMessage?.text ||
      "";

    if (isGroup && sender && !text.startsWith(config.prefix)) {
      checkAntispam(sock, from, sender, msg).catch(console.error);
    }

    handleMessage(sock, msg).catch(console.error);
  });

  sock.ev.on("group-participants.update", async (event) => {
    const { id: groupId, participants, action, author } = event;

    // ==== Anti auto-add: bot ditambahin tanpa izin owner -> keluar ====
    if (action === "add") {
      const botJidNorm = jidNormalizedUser(sock.user.id);
      const botAdded = participants.some((p) => jidNormalizedUser(p) === botJidNorm);
      if (botAdded) {
        let allowedByOwner = false;
        if (author) {
          allowedByOwner = await isOwner(sock, true, groupId, author);
        } else {
          try {
            const metadata = await sock.groupMetadata(groupId);
            for (const p of metadata.participants) {
              if (await isOwner(sock, true, groupId, p.id)) {
                allowedByOwner = true;
                break;
              }
            }
          } catch (e) {}
        }
        if (!allowedByOwner) {
          console.log(`Ditambahkan ke grup ${groupId} tanpa izin owner, keluar...`);
          await sleep(1000 + Math.random() * 500);
          try {
            await sock.sendMessage(groupId, { text:"🚫 Bot cuma boleh ditambahkan oleh owner. Bye!" });
          } catch (e) {}
          await sleep(1000 + Math.random() * 500);
          await sock.groupLeave(groupId);
          return;
        }
      }
    }

    // ==== Anti-kudeta: owner di-kick/keluar -> bot ikut keluar ====
    if (action === "remove") {
      for (const p of participants) {
        const ownerRemoved = await isOwner(sock, true, groupId, p);
        if (ownerRemoved) {
          console.log(`Owner keluar/di-kick dari grup ${groupId}, bot ikut keluar...`);
          await sleep(1000 + Math.random() * 500);
          try {
            await sock.sendMessage(groupId, { text: "👋 Owner udah nggak ada di grup ini, bot pamit juga." });
          }catch (e) {}
          await sleep(1000 + Math.random() * 500);
          await sock.groupLeave(groupId);
          return;
        }
      }
    }

    if (!db.isWelcomeActive(groupId)) return;

    try {
      const metadata = await sock.groupMetadata(groupId);
      for (const participant of participants) {
        if (action === "add") {
          await sock.sendMessage(groupId, {
            text: `👋 Selamat datang @${participant.split("@")[0]} di grup *${metadata.subject}*!\nBaca deskripsi grup & jangan lupa cek ${config.prefix}menu ya.`,
            mentions: [participant],
          });
        } else if (action === "remove") {
          await sock.sendMessage(groupId, {
            text: `👋 @${participant.split("@")[0]} telah meninggalkan grup.`,
            mentions: [participant],
          });
        }
      }
    } catch (e) {
      if (e?.data !== 404 && e?.output?.statusCode !== 404) {
        console.error("Welcome/leave error:", e.message || e);
      }
    }
  });

  // ==== Anti auto-add versi 2: nangkep grup yang BARU dibuat & bot ====
  // ==== langsung dimasukin pas pembuatan (event beda dari update biasa) ====
  sock.ev.on("groups.upsert", async (groups) => {
    for (const g of groups) {
      try {
        let allowed = false;

        if (g.owner) {
          allowed = await isOwner(sock, true, g.id, g.owner);
        }

        if (!allowed) {
          let participants = g.participants;
          if (!participants) {
            const metadata = await sock.groupMetadata(g.id);
            participants = metadata.participants;
          }
          for (const p of participants) {
            if (await isOwner(sock, true, g.id, p.id)) {
              allowed = true;
              break;
            }
          }
        }

        if (!allowed) {
          console.log(`Grup baru ${g.id} dibuat tanpa owner, bot keluar...`);
          await sleep(1000 + Math.random() * 500);
          try {
            await sock.sendMessage(g.id, { text: "🚫 Bot cuma boleh ditambahkan oleh owner. Bye!" });
          } catch (e) {}
          await sleep(1000 + Math.random() * 500);
          await sock.groupLeave(g.id);
        }
      } catch (e) {
        console.error("groups.upsert anti-add error:", e);
      }
    }
  });

  return sock;
}

startBot().catch((err) => console.error("Gagal start bot:", err));
